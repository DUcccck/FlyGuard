"""Syslog-приймач: FortiWeb шле логи напряму у FlyGuard.

  FortiWeb ──syslog (UDP/TCP)──► FlyGuard ──► alerts.jsonl / blocklist / CLI для FortiWeb
                                    └──(опц.) пересилання далі у ваш SIEM

Режими:
  * навчання  — якщо моделі ще немає: логи зберігаються на диск, після --learn записів
                муха навчається автоматично і переходить у режим захисту;
  * захист    — кожен запит оцінюється на льоту.
"""
from __future__ import annotations

import json
import os
import queue
import signal
import socket
import socketserver
import threading
import time
from collections import defaultdict, deque

import numpy as np

from .features import CHANNELS, N_CHANNELS, BehaviorTracker, featurize
from .fly import MushroomBody
from .parsers import iter_lines, iter_records

LINES: "queue.Queue[str]" = queue.Queue(maxsize=200_000)


# ---------------- мережа ----------------
class _UDP(socketserver.BaseRequestHandler):
    def handle(self):
        data = self.request[0].decode("utf-8", errors="replace")
        for line in data.splitlines():
            if line.strip():
                _put(line)


class _TCP(socketserver.StreamRequestHandler):
    def handle(self):
        for raw in self.rfile:
            line = raw.decode("utf-8", errors="replace").strip()
            if line:
                _put(line)


def _put(line: str):
    try:
        LINES.put_nowait(line)
    except queue.Full:
        pass  # краще втратити лог, ніж покласти сервер


class _ThreadedUDP(socketserver.UDPServer):
    # однопотоковий прийом + великий буфер ядра: UDP не губиться на піках
    allow_reuse_address = True
    max_packet_size = 65535

    def server_bind(self):
        try:
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 16 * 1024 * 1024)
        except OSError:
            pass
        super().server_bind()


class _ThreadedTCP(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True


def start_servers(host: str, udp_port: int | None, tcp_port: int | None):
    servers = []
    if udp_port:
        servers.append(_ThreadedUDP((host, udp_port), _UDP))
    if tcp_port:
        servers.append(_ThreadedTCP((host, tcp_port), _TCP))
    for s in servers:
        threading.Thread(target=s.serve_forever, daemon=True).start()
    return servers


# ---------------- детектор ----------------
class Detector:
    """Оцінює запити і веде стан для веб-інтерфейсу. Усі зміни — під self.lock."""

    def __init__(self, mb: MushroomBody, threshold: float, min_hits: int, window: int,
                 alerts_path: str, blocklist_path: str, whitelist: set[str], whitelist_path: str = ""):
        self.lock = threading.RLock()
        self.mb, self.thr = mb, threshold
        self.min_hits, self.window = min_hits, window
        self.tracker = BehaviorTracker()
        self.hits = defaultdict(deque)
        self.whitelist, self.whitelist_path = whitelist, whitelist_path
        self.alerts = open(alerts_path, "a", encoding="utf-8")
        self.blocklist_path = blocklist_path
        self.approved_path = blocklist_path.rsplit(".", 1)[0] + ".approved.txt"
        self.blocked: list[str] = _read_list(blocklist_path)
        self.approved: set[str] = set(_read_list(self.approved_path))
        self.rejected: set[str] = set()
        self.cand: dict[str, dict] = {ip: {"ip": ip, "hits": 0, "risk": 0.0, "why": [], "url": "", "last": ""}
                                      for ip in self.blocked}
        self.recent: deque = deque(maxlen=300)
        self.vectors: dict[int, tuple] = {}            # id алерту -> (вектор, запит) для «мозку»
        self.last: tuple | None = None                  # останній оцінений запит
        self.minutes: dict[int, list[int]] = {}       # хвилина -> [запитів, алертів]
        self.ip_alerts: dict[str, int] = defaultdict(int)
        self.n = self.n_alerts = 0
        self.on_candidate = None       # callback(cand) -> FlySOAR
        from .features import NetTracker
        self.tracker_net = NetTracker()
        self.mb_net = None             # мережева муха (встановлюється, коли є model_net.npz)
        self.thr_net = 0.9
        self.vectors_net: dict[int, tuple] = {}
        self.last_net: tuple | None = None

    def _bucket(self) -> list[int]:
        m = int(time.time() // 60)
        if m not in self.minutes:
            self.minutes[m] = [0, 0]
            for old in [k for k in self.minutes if k < m - 59]:
                del self.minutes[old]
        return self.minutes[m]

    def process(self, rec: dict):
        kind = rec.get("kind", "web")
        if kind == "conn":
            if getattr(self, "mb_net", None) is not None:
                self._process_net(rec)
            return
        if kind != "web" or self.mb is None:
            return
        with self.lock:
            self.n += 1
            self._bucket()[0] += 1
            x = featurize([rec], self.tracker)
            r = float(self.mb.risk(x)[0])
            self.last = (x[0], _brief(rec), r)
            if r < self.thr:
                return
            why = self.mb.explain(x[0], CHANNELS)
            self._register(rec, r, why, src="web", vec=x[0],
                           extra={"method": rec["method"], "url": rec["url"][:300],
                                  "fortiweb_action": rec["action"]})

    def _process_net(self, rec: dict):
        with self.lock:
            self.n += 1
            self._bucket()[0] += 1
            from .features import neturize, NET_CHANNELS
            x = neturize([rec], self.tracker_net)
            r = float(self.mb_net.risk(x)[0])
            self.last_net = (x[0], _brief(rec), r)
            if r < self.thr_net:
                return
            why = self.mb_net.explain(x[0], NET_CHANNELS)
            label = f'{rec.get("proto","")}:{rec.get("dst","")}:{rec.get("dport","")}'
            self.vectors_net[self.n_alerts + 1] = (x[0], _brief(rec), r)
            if len(self.vectors_net) > 300:
                del self.vectors_net[min(self.vectors_net)]
            self._register(rec, r, why, src="net", vec=None,
                           extra={"method": rec.get("proto", ""), "url": label,
                                  "fortiweb_action": rec.get("action", "")})

    def _register(self, rec: dict, r: float, why: list, src: str, vec, extra: dict):
        """Спільна частина для web- і net-алертів: запис, лічильники, кандидат на блокування."""
        self._bucket()[1] += 1
        ip = rec["src"]
        self.n_alerts += 1
        self.ip_alerts[ip] += 1
        alert = {"id": self.n_alerts, "time": f'{rec.get("date","")} {rec.get("time","")}'.strip(),
                 "src": ip, "risk": round(r, 3), "kind": src, "why": why, **extra}
        self.recent.append(alert)
        if vec is not None:
            self.vectors[self.n_alerts] = (vec, _brief(rec), r)
            if len(self.vectors) > 300:
                del self.vectors[min(self.vectors)]
        self.alerts.write(json.dumps(alert, ensure_ascii=False) + "\n")
        self.alerts.flush()
        if ip in self.cand:
            c = self.cand[ip]
            c.update(hits=c["hits"] + 1, risk=max(c["risk"], r), last=alert["time"])
            c.setdefault("kind", src)
            if not c["why"] or r >= c["risk"]:
                c.update(why=why, url=extra.get("url", "")[:200])
        q = self.hits[ip]
        q.append(self.n)
        if len(self.hits) > 50_000:
            for old in [k for k, v in self.hits.items() if not v or self.n - v[-1] > self.window]:
                del self.hits[old]
        if len(self.ip_alerts) > 50_000:
            for old, _ in sorted(self.ip_alerts.items(), key=lambda kv: kv[1])[:25_000]:
                del self.ip_alerts[old]
        while q and self.n - q[0] > self.window:
            q.popleft()
        if (len(q) >= self.min_hits and _valid_ip(ip) and ip not in self.cand
                and ip not in self.whitelist and ip not in self.rejected):
            self.blocked.append(ip)
            self.cand[ip] = {"ip": ip, "hits": len(q), "risk": r, "why": why, "kind": src,
                             "url": extra.get("url", "")[:200], "last": alert["time"]}
            print(f"[BLOCK dry-run/{src}] {ip} risk={r:.2f} {why} {extra.get('url','')[:80]}", flush=True)
            with open(self.blocklist_path, "a") as f:
                f.write(ip + "\n")
            self._write_cli()
            if self.on_candidate:
                try:
                    self.on_candidate(dict(self.cand[ip]))
                except Exception as e:
                    print(f"[SOAR] помилка обробки кандидата: {e}", flush=True)

    # ---- дії з веб-інтерфейсу ----
    def _write_cli(self):
        from .cli import _fortiweb_cli
        with open(self.blocklist_path + ".fortiweb.txt", "w") as f:
            f.write(_fortiweb_cli(self.blocked) + "\n")

    def _save_lists(self):
        with open(self.blocklist_path, "w") as f:
            f.write("".join(ip + "\n" for ip in self.blocked))
        with open(self.approved_path, "w") as f:
            f.write("".join(ip + "\n" for ip in sorted(self.approved)))
        self._write_cli()

    def approve(self, ip: str):
        with self.lock:
            if ip in self.cand:
                self.approved.add(ip)
                self._save_lists()

    def reject(self, ip: str, whitelist: bool = False):
        with self.lock:
            self.cand.pop(ip, None)
            self.approved.discard(ip)
            if ip in self.blocked:
                self.blocked.remove(ip)
            self.rejected.add(ip)
            self.hits.pop(ip, None)
            if whitelist and ip not in self.whitelist:
                self.whitelist.add(ip)
                if self.whitelist_path:
                    with open(self.whitelist_path, "a") as f:
                        f.write(f"{ip}  # додано з веб-інтерфейсу {time.strftime('%Y-%m-%d %H:%M')}\n")
            self._save_lists()

    def set_threshold(self, thr: float, manual: bool = True):
        with self.lock:
            self.thr = min(max(thr, 0.0), 1.0)
            self.manual_thr = manual

    def swap_model(self, mb: MushroomBody):
        with self.lock:
            self.mb = mb

    def set_net_model(self, mb, thr: float):
        with self.lock:
            self.mb_net = mb
            self.thr_net = thr

    def brain(self, alert_id: int | None = None, fly: str = "web") -> dict | None:
        with self.lock:
            if fly == "net":
                from .features import NET_CHANNELS
                mb, chans, vecs, last, thr = (self.mb_net, NET_CHANNELS,
                                              self.vectors_net, self.last_net, self.thr_net)
            else:
                mb, chans, vecs, last, thr = (self.mb, CHANNELS, self.vectors, self.last, self.thr)
            if mb is None:
                return None
            if alert_id is not None and alert_id in vecs:
                x, req, r = vecs[alert_id]
                kind = "alert"
            elif last is not None:
                x, req, r = last
                kind = "live"
            else:
                return None
            t = mb.trace(x, chans)
            t.update(request=req, kind=kind, id=alert_id if kind == "alert" else None,
                     threshold=thr, alert=r >= thr, fly=fly)
            return t

    def snapshot(self) -> dict:
        with self.lock:
            now = int(time.time() // 60)
            series = [[(now - 59 + i) * 60] + self.minutes.get(now - 59 + i, [0, 0]) for i in range(60)]
            top = sorted(self.ip_alerts.items(), key=lambda kv: -kv[1])[:10]
            cands = []
            for ip in reversed(self.blocked):
                c = dict(self.cand.get(ip, {"ip": ip}))
                c["status"] = "approved" if ip in self.approved else "pending"
                cands.append(c)
            return {"requests": self.n, "alerts": self.n_alerts, "threshold": self.thr,
                    "series": series, "recent": list(reversed(self.recent))[:100],
                    "top_ips": [{"ip": ip, "alerts": n} for ip, n in top],
                    "candidates": cands, "approved": sorted(self.approved),
                    "whitelist": sorted(self.whitelist),
                    "net_enabled": self.mb_net is not None, "net_threshold": self.thr_net}


def _brief(rec: dict) -> dict:
    method, url = rec["method"], rec["url"][:300]
    if not url and rec.get("kind") == "conn":          # мережеве з'єднання, не HTTP
        proto = (rec.get("proto") or "").upper()
        method = proto or method
        url = f'→ {rec.get("dst","?")}:{rec.get("dport","?")}'
        if rec.get("service_id"):
            url += f' ({rec["service_id"]})'
    return {"time": f'{rec["date"]} {rec["time"]}', "src": rec["src"], "method": method,
            "url": url, "agent": rec["agent"][:160], "retcode": rec["retcode"],
            "fortiweb_action": rec["action"]}


def _valid_ip(ip: str) -> bool:
    import ipaddress
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


def _read_list(path: str) -> list[str]:
    if not path or not os.path.exists(path):
        return []
    out = []
    for l in open(path, encoding="utf-8"):
        v = l.split("#")[0].strip()
        if v and v not in out:
            out.append(v)
    return out


def _is_request(rec: dict) -> bool:
    # потрібен URL; службові event-логи пропускаємо (FortiWeb type=event, Check Point type=control тощо)
    return bool(rec.get("url")) and rec.get("type", "").lower() not in ("event", "control", "alert")


def train_from(path: str, model_path: str, fpr: float, unsupervised: bool) -> MushroomBody:
    # потоково, без зберігання всіх записів у пам'яті
    from .features import BehaviorTracker, content_features, trigram_hash
    tracker, rows, labels = BehaviorTracker(), [], []
    for r in iter_records(path):
        if _is_request(r):
            rows.append(np.concatenate([content_features(r), tracker.update(r), trigram_hash(r)]))
            labels.append(r["label"])
    if len(rows) < 50:
        print(f"[TRAIN] HTTP-запитів замало ({len(rows)}), веб-муха не навчена", flush=True)
        return None
    X = np.vstack(rows).astype(np.float32)
    del rows
    y = None if unsupervised else np.array(labels)
    mb = MushroomBody(N_CHANNELS).fit(X, y)
    benign = X if y is None else X[y == 0]
    mb.threshold = float(np.quantile(mb.risk(benign), 1 - fpr))
    mb.save(model_path)
    print(f"[TRAIN] веб-муха навчена на {len(X)} запитах, поріг {mb.threshold:.3f} -> {model_path}", flush=True)
    return mb


def train_net_from(path: str, model_path: str, fpr: float):
    """Навчання мережевої мухи на з'єднаннях (unsupervised: норма = весь трафік)."""
    from .features import NetTracker, net_static, N_NET
    tracker, rows = NetTracker(), []
    for r in iter_records(path):
        if r.get("kind") == "conn":
            rows.append(np.concatenate([net_static(r), tracker.update(r)]))
    if len(rows) < 200:
        print(f"[TRAIN] мережевих з'єднань замало ({len(rows)}), мережева муха не навчена", flush=True)
        return None, 0.9
    X = np.vstack(rows).astype(np.float32)
    mb = MushroomBody(N_NET).fit(X)
    thr = float(np.quantile(mb.risk(X), 1 - fpr))
    mb.threshold = thr
    mb.save(model_path)
    print(f"[TRAIN] мережева муха навчена на {len(X)} з'єднаннях, поріг {thr:.3f} -> {model_path}", flush=True)
    return mb, thr


class App:
    """Спільний стан між syslog-циклом і веб-інтерфейсом."""

    def __init__(self, a):
        self.a = a
        self.lock = threading.RLock()
        # Дві мухи вчаться НЕЗАЛЕЖНО: у кожної свій лічильник, ціль, момент старту,
        # прапор навчання і помилка. Веб-муха — на HTTP-запитах, мережева — на з'єднаннях.
        tgt = getattr(a, "learn", 5000)
        self.learn_web = tgt
        self.learn_net = getattr(a, "learn_net", None) or tgt
        self.learned_web = self.learned_net = 0
        self.next_web, self.next_net = self.learn_web, self.learn_net
        self.training_web = self.training_net = False
        self.train_error_web = self.train_error_net = ""
        self.started = time.time()
        self.received = 0
        self.whitelist = set(_read_list(a.whitelist))
        # FlySOAR / FlyBAS / FlyHoney
        from .store import Store
        from .soar import SoarEngine
        from .bas import BasRunner
        from .honeypot import HoneyNet
        self.store = Store(getattr(a, "config", "config.json"))
        self.soar = SoarEngine(self.store)
        self.bas = BasRunner(self.store, alert_lookup=lambda: self.det.recent if self.det else [])
        self.honey = HoneyNet(self.store, on_hit=self._honey_hit)
        self.honey.start()
        web = MushroomBody.load(a.model) if os.path.exists(a.model) else None
        net = MushroomBody.load(self.net_path) if os.path.exists(self.net_path) else None
        # Детектор існує ЗАВЖДИ (навіть без жодної моделі) — так кожна муха може
        # перейти в режим захисту окремо, не чекаючи іншу.
        self.det = self._make_det(web)
        if net is not None:
            self.det.set_net_model(net, float(getattr(net, "threshold", 0.9)))

    @property
    def net_path(self) -> str:
        m = self.a.model
        return m[:-4] + "_net.npz" if m.endswith(".npz") else m + "_net.npz"

    def _honey_hit(self, cand: dict):
        # дотик до пастки -> одразу у SOAR як максимальна підозра
        self.soar.on_candidate(cand)

    def _make_det(self, mb):
        a = self.a
        thr = a.threshold or float(getattr(mb, "threshold", 0.95)) if mb is not None else (a.threshold or 0.95)
        det = Detector(mb, thr, a.min_hits, a.window, a.alerts, a.blocklist, self.whitelist, a.whitelist)
        det.on_candidate = self.soar.on_candidate
        return det

    def _have_save(self) -> bool:
        return bool(self.a.save) and os.path.exists(self.a.save)

    def _apply_web(self, mb: MushroomBody):
        with self.lock:
            self.det.swap_model(mb)
            if not getattr(self.det, "manual_thr", False):
                self.det.set_threshold(self.a.threshold or mb.threshold, manual=False)

    def train_web_async(self) -> str:
        with self.lock:
            if self.training_web:
                return "Навчання веб-мухи вже триває"
            if not self._have_save():
                return "Немає збережених логів"
            self.training_web, self.train_error_web = True, ""

        def job():
            try:
                if self.save_file:
                    self.save_file.flush()
                mb = train_from(self.a.save, self.a.model, self.a.fpr, self.a.unsupervised)
                if mb is None:
                    raise ValueError("замало HTTP-запитів для веб-мухи")
                self._apply_web(mb)
                print("[TRAIN] веб-муха у режимі ЗАХИСТУ", flush=True)
            except Exception as e:
                self.train_error_web = str(e)
                print(f"[TRAIN] веб-муха: помилка: {e}", flush=True)
            finally:
                self.training_web = False

        threading.Thread(target=job, daemon=True).start()
        return "Навчання веб-мухи запущено"

    def train_net_async(self) -> str:
        with self.lock:
            if self.training_net:
                return "Навчання мережевої мухи вже триває"
            if not self._have_save():
                return "Немає збережених логів"
            self.training_net, self.train_error_net = True, ""

        def job():
            try:
                if self.save_file:
                    self.save_file.flush()
                net, net_thr = train_net_from(self.a.save, self.net_path, self.a.fpr)
                if net is None:
                    raise ValueError("замало мережевих з'єднань для мережевої мухи")
                with self.lock:
                    self.det.set_net_model(net, net_thr)
                print("[TRAIN] мережева муха у режимі ЗАХИСТУ", flush=True)
            except Exception as e:
                self.train_error_net = str(e)
                print(f"[TRAIN] мережева муха: помилка: {e}", flush=True)
            finally:
                self.training_net = False

        threading.Thread(target=job, daemon=True).start()
        return "Навчання мережевої мухи запущено"

    def train_async(self, min_records: int = 1000) -> str:
        """Ручний запуск: навчити обидві мухи на зібраних логах."""
        if not self._have_save():
            return "Немає збережених логів для навчання"
        self.train_web_async()
        self.train_net_async()
        return "Навчання запущено (веб + мережа)"

    def ingest(self, rec: dict):
        """Маршрутизація запису: якщо модель цієї мухи готова — оцінюємо,
        інакше рахуємо його у навчання саме цієї мухи (незалежно від іншої)."""
        kind = rec.get("kind")
        det = self.det
        if kind == "web":
            if det.mb is not None:
                _safe(det, rec)
            else:
                self._learn("web", rec)
        elif kind == "conn":
            if det.mb_net is not None:
                _safe(det, rec)
            else:
                self._learn("net", rec)

    def _learn(self, fly: str, rec: dict):
        # Перша спроба на цілі; далі — повторні щоразу, коли набереться ще стільки ж.
        # Попередня помилка НЕ блокує повтор (інакше муха застрягла б у навчанні).
        if fly == "web":
            self.learned_web += 1
            if self.learned_web >= self.next_web and not self.training_web:
                self.next_web = self.learned_web + max(2000, self.learn_web)
                self.train_web_async()
        else:
            self.learned_net += 1
            if self.learned_net >= self.next_net and not self.training_net:
                self.next_net = self.learned_net + max(2000, self.learn_net)
                self.train_net_async()

    def state(self) -> dict:
        det = self.det
        web_ready = det.mb is not None
        net_ready = det.mb_net is not None
        base = {"mode": "protect" if (web_ready or net_ready) else "learn",
                "web_ready": web_ready, "net_ready": net_ready,
                "learned_web": self.learned_web, "learn_web": self.learn_web,
                "training_web": self.training_web, "train_error_web": self.train_error_web,
                "learned_net": self.learned_net, "learn_net": self.learn_net,
                "training_net": self.training_net, "train_error_net": self.train_error_net,
                # сумісність зі старим інтерфейсом
                "learned": self.learned_web + self.learned_net,
                "learn_target": self.learn_web + self.learn_net,
                "training": self.training_web or self.training_net,
                "train_error": self.train_error_web or self.train_error_net,
                "uptime": int(time.time() - self.started), "received": self.received,
                "queue": LINES.qsize(), "forward": self.a.forward or "",
                "soar": self.soar.snapshot(), "bas": self.bas.snapshot(),
                "honey": self.honey.snapshot(), "integrations": self.store.public().get("integrations", {})}
        base.update(det.snapshot())
        return base


def _safe(det: "Detector", rec: dict):
    try:
        det.process(rec)
    except Exception as e:  # один кривий лог не має зупиняти захист
        print(f"[WARN] не вдалося обробити запис: {e}", flush=True)


def run(a):
    servers = start_servers(a.host, a.udp, a.tcp)
    ports = ", ".join(f"{p.upper()} {getattr(a, p)}" for p in ("udp", "tcp") if getattr(a, p))
    print(f"FlyGuard слухає syslog на {a.host} ({ports})", flush=True)

    fwd = None
    if a.forward:
        h, p = a.forward.rsplit(":", 1)
        fwd = (socket.socket(socket.AF_INET, socket.SOCK_DGRAM), (h, int(p)))
        print(f"Пересилаю всі логи далі у SIEM: {a.forward} (UDP)", flush=True)

    netp = a.model[:-4] + "_net.npz" if a.model.endswith(".npz") else a.model + "_net.npz"
    if not a.save and (not os.path.exists(a.model) or not os.path.exists(netp)):
        a.save = "fortiweb_raw.log"  # хоч одній мусі потрібні дані -> зберігаємо логи
    app = App(a)
    app.save_file = open(a.save, "a", encoding="utf-8") if a.save else None
    web_on, net_on = app.det.mb is not None, app.det.mb_net is not None
    if web_on or net_on:
        print(f"Режим ЗАХИСТУ — веб-муха: {'так' if web_on else 'вчиться'}, "
              f"мережева муха: {'так' if net_on else 'вчиться'}", flush=True)
    else:
        print(f"Моделей ще немає -> НАВЧАННЯ (веб ціль {app.learn_web}, мережа ціль {app.learn_net}) у {a.save}", flush=True)

    if a.web_port:
        from .web import start_web
        start_web(app, a.web_host, a.web_port, a.web_password)

    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    last_stat = time.time()
    save = app.save_file
    try:
        while not stop.is_set():
            try:
                line = LINES.get(timeout=1.0)
            except queue.Empty:
                line = None
            if line is not None:
                app.received += 1
                if save:
                    save.write(line + "\n")
                if fwd:
                    fwd[0].sendto(line.encode("utf-8"), fwd[1])
                for rec in iter_lines([line]):
                    if rec.get("kind") not in ("web", "conn"):  # службові логи без URL і без з'єднання
                        continue
                    # Кожна муха обробляється окремо: готова — оцінює, ні — вчиться.
                    app.ingest(rec)
            if time.time() - last_stat > 60:
                last_stat = time.time()
                if save:
                    save.flush()
                if app.det:
                    d = app.det
                    print(f"[STAT] запитів {d.n}, алертів {d.n_alerts}, IP у blocklist {len(d.blocked)}",
                          flush=True)
    except KeyboardInterrupt:
        pass
    finally:
        for s in servers:
            s.shutdown()
        if save:
            save.close()
        print("Зупинено.")
