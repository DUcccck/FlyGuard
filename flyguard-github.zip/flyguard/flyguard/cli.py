"""FlyGuard CLI.

  python -m flyguard sample                       # згенерувати тестові логи FortiWeb
  python -m flyguard evaluate LOG [--truth FILE]  # муха vs Isolation Forest
  python -m flyguard train LOG -o model.npz       # навчити муху на ваших логах
  python -m flyguard guard LOG|- -m model.npz     # потоковий режим: алерти + blocklist
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from collections import defaultdict, deque

import numpy as np

from .features import CHANNELS, N_CHANNELS, BehaviorTracker, featurize
from .fly import MushroomBody
from .parsers import iter_lines, iter_records


def _load(path):
    recs = list(iter_records(path))
    if not recs:
        sys.exit(f"Не знайдено жодного запису в {path}. Перевірте формат (див. README).")
    X = featurize(recs)
    y_fw = np.array([r["label"] for r in recs])
    return recs, X, y_fw


def cmd_sample(a):
    from .sample import write
    for path in (a.out, a.truth):
        if os.path.dirname(path):
            os.makedirs(os.path.dirname(path), exist_ok=True)
    write(a.out, a.truth, n_benign=a.benign, n_attack=a.attacks)
    print(f"Записано {a.out} та {a.truth}")


def _metrics(y, s, fpr_target=0.01):
    from sklearn.metrics import average_precision_score, roc_auc_score
    thr = np.quantile(s[y == 0], 1 - fpr_target)
    pred = s > thr
    tp = (pred & (y == 1)).sum()
    return dict(roc_auc=roc_auc_score(y, s), pr_auc=average_precision_score(y, s),
                recall_at_1pct_fpr=tp / max((y == 1).sum(), 1),
                precision_at_1pct_fpr=tp / max(pred.sum(), 1), thr=thr)


def cmd_evaluate(a):
    from sklearn.ensemble import IsolationForest
    recs, X, y_fw = _load(a.log)
    y = np.loadtxt(a.truth, dtype=int) if a.truth else y_fw
    n_tr = int(len(X) * a.train_frac)
    Xtr, Xte, ytr_fw, yte, fw_te = X[:n_tr], X[n_tr:], y_fw[:n_tr], y[n_tr:], y_fw[n_tr:]
    print(f"Записів: {len(X)} | навчання: {n_tr} | тест: {len(Xte)} | атак у тесті: {yte.sum()}"
          f" (FortiWeb позначив {fw_te[yte == 1].sum()})\n")

    t = time.time()
    mb_u = MushroomBody(N_CHANNELS).fit(Xtr[ytr_fw == 0])          # лише новизна
    mb_s = MushroomBody(N_CHANNELS).fit(Xtr, ytr_fw)               # новизна + дофамін від FortiWeb
    t_fly = time.time() - t
    iso = IsolationForest(n_estimators=200, random_state=0).fit(Xtr[ytr_fw == 0])
    scores = {
        "Муха: лише новизна (без міток)": mb_u.risk(Xte),
        "Муха: новизна + дофамін FortiWeb": mb_s.risk(Xte),
        "Isolation Forest (базова лінія)": -iso.score_samples(Xte),
    }
    print(f"{'Модель':38s} ROC-AUC  PR-AUC  Recall@1%FPR  Precision")
    for name, s in scores.items():
        m = _metrics(yte, s)
        print(f"{name:38s} {m['roc_auc']:.3f}    {m['pr_auc']:.3f}   {m['recall_at_1pct_fpr']:.3f}"
              f"         {m['precision_at_1pct_fpr']:.3f}")

    # найцікавіше: атаки, які FortiWeb пропустив
    missed = (yte == 1) & (fw_te == 0)
    if a.truth and missed.any():
        print(f"\nАтаки, які FortiWeb ПРОПУСТИВ: {missed.sum()}")
        for name, s in scores.items():
            thr = np.quantile(s[yte == 0], 0.99)
            print(f"  {name:38s} знайдено {(s[missed] > thr).mean():.1%}")
    print(f"\nЧас навчання мухи: {t_fly:.2f} c")


def cmd_train(a):
    recs, X, y_fw = _load(a.log)
    y = None if a.unsupervised else y_fw
    mb = MushroomBody(N_CHANNELS, n_kc=a.kc, sparsity=a.sparsity).fit(X, y)
    benign = X if y is None else X[y == 0]
    mb.threshold = float(np.quantile(mb.risk(benign), 1 - a.fpr))
    mb.save(a.out)
    print(f"Навчено на {len(X)} записах ({int(y_fw.sum())} позначено FortiWeb як атаки). "
          f"Поріг ризику: {mb.threshold:.3f}. Модель: {a.out}")


def _fortiweb_cli(ips, name="flyguard-block"):
    out = ["config waf ip-list", f'  edit "{name}"', "    config members"]
    for i, ip in enumerate(ips, 1):
        out += [f"      edit {i}", "        set type black-ip", f"        set ip {ip}", "      next"]
    out += ["    end", "  next", "end"]
    return "\n".join(out)


def cmd_guard(a):
    mb = MushroomBody.load(a.model)
    thr = a.threshold if a.threshold is not None else float(getattr(mb, "threshold", 0.9))
    tracker = BehaviorTracker()
    hits = defaultdict(deque)
    blocked: list[str] = []
    src = sys.stdin if a.log == "-" else open(a.log, encoding="utf-8", errors="replace")

    def lines():
        while True:
            line = src.readline()
            if line:
                yield line
            elif a.follow:
                time.sleep(0.5)
            else:
                return

    alerts = open(a.alerts, "w", encoding="utf-8")
    n = 0
    for rec in iter_lines(lines()):
        n += 1
        x = featurize([rec], tracker)
        r = float(mb.risk(x)[0])
        if r < thr:
            continue
        ip = rec["src"]
        why = mb.explain(x[0], CHANNELS)
        alerts.write(json.dumps({"time": f'{rec["date"]} {rec["time"]}', "src": ip, "risk": round(r, 3),
                                 "url": rec["url"][:300], "fortiweb_action": rec["action"], "why": why},
                                ensure_ascii=False) + "\n")
        q = hits[ip]
        q.append(n)
        while q and n - q[0] > a.window:
            q.popleft()
        if len(q) >= a.min_hits and ip not in blocked:
            blocked.append(ip)
            print(f"[BLOCK{' dry-run' if not a.apply else ''}] {ip} risk={r:.2f} {why} {rec['url'][:80]}")
            with open(a.blocklist, "a") as f:
                f.write(ip + "\n")
    alerts.close()
    if blocked:
        with open(a.blocklist + ".fortiweb.txt", "w") as f:
            f.write(_fortiweb_cli(blocked) + "\n")
    print(f"\nОброблено {n} запитів, кандидатів на блокування: {len(blocked)}. "
          f"Алерти: {a.alerts}; blocklist: {a.blocklist}"
          + (f"; CLI для FortiWeb: {a.blocklist}.fortiweb.txt" if blocked else ""))


def main(argv=None):
    p = argparse.ArgumentParser(prog="flyguard", description="Детектор атак на основі мозку мухи")
    sp = p.add_subparsers(dest="cmd", required=True)

    s = sp.add_parser("sample", help="згенерувати тестові логи FortiWeb")
    s.add_argument("--out", default="data/sample_fortiweb.log")
    s.add_argument("--truth", default="data/sample_truth.txt")
    s.add_argument("--benign", type=int, default=20000)
    s.add_argument("--attacks", type=int, default=1200)
    s.set_defaults(fn=cmd_sample)

    s = sp.add_parser("evaluate", help="порівняти муху з Isolation Forest")
    s.add_argument("log")
    s.add_argument("--truth", help="файл зі справжніми мітками 0/1 (по рядку на запис)")
    s.add_argument("--train-frac", type=float, default=0.5)
    s.set_defaults(fn=cmd_evaluate)

    s = sp.add_parser("train", help="навчити муху")
    s.add_argument("log")
    s.add_argument("-o", "--out", default="model.npz")
    s.add_argument("--unsupervised", action="store_true", help="не використовувати мітки FortiWeb")
    s.add_argument("--kc", type=int, default=2000, help="кількість клітин Кеньона")
    s.add_argument("--sparsity", type=float, default=0.05)
    s.add_argument("--fpr", type=float, default=0.005, help="допустима частка хибних алертів")
    s.set_defaults(fn=cmd_train)

    s = sp.add_parser("guard", help="потоковий режим (за замовчуванням dry-run)")
    s.add_argument("log", help="файл логів або '-' для stdin")
    s.add_argument("-m", "--model", default="model.npz")
    s.add_argument("--threshold", type=float)
    s.add_argument("--min-hits", type=int, default=3, help="скільки підозрілих запитів до блокування IP")
    s.add_argument("--window", type=int, default=500, help="вікно (у запитах) для --min-hits")
    s.add_argument("--follow", action="store_true", help="чекати нових рядків (як tail -f)")
    s.add_argument("--alerts", default="alerts.jsonl")
    s.add_argument("--blocklist", default="blocklist.txt")
    s.add_argument("--apply", action="store_true", help="зарезервовано для автоматичного блокування")
    s.set_defaults(fn=cmd_guard)

    s = sp.add_parser("listen", help="приймати syslog напряму від FortiWeb")
    s.add_argument("--host", default="0.0.0.0")
    s.add_argument("--udp", type=int, default=5140, help="UDP-порт (0 — вимкнути)")
    s.add_argument("--tcp", type=int, default=0, help="TCP-порт (0 — вимкнути)")
    s.add_argument("-m", "--model", default="model.npz", help="якщо файлу немає — спершу режим навчання")
    s.add_argument("--learn", type=int, default=200_000, help="скільки HTTP-запитів зібрати перед навчанням веб-мухи")
    s.add_argument("--learn-net", type=int, default=None, dest="learn_net",
                   help="скільки з'єднань зібрати перед навчанням мережевої мухи (типово — як --learn)")
    s.add_argument("--save", default="fortiweb_raw.log", help="куди зберігати сирі логи ('' — не зберігати)")
    s.add_argument("--forward", help="переслати логи далі у SIEM, напр. 10.0.0.5:514")
    s.add_argument("--whitelist", default="whitelist.txt", help="IP, які ніколи не блокувати")
    s.add_argument("--threshold", type=float)
    s.add_argument("--min-hits", type=int, default=3)
    s.add_argument("--window", type=int, default=500)
    s.add_argument("--fpr", type=float, default=0.005)
    s.add_argument("--unsupervised", action="store_true")
    s.add_argument("--alerts", default="alerts.jsonl")
    s.add_argument("--blocklist", default="blocklist.txt")
    s.add_argument("--web-host", default="127.0.0.1",
                   help="адреса веб-інтерфейсу (0.0.0.0 — доступ з мережі)")
    s.add_argument("--web-port", type=int, default=8080, help="порт веб-інтерфейсу (0 — вимкнути)")
    s.add_argument("--web-password", default=os.environ.get("FLYGUARD_WEB_PASSWORD", ""),
                   help="пароль веб-інтерфейсу (або змінна FLYGUARD_WEB_PASSWORD)")
    s.add_argument("--config", default="config.json", help="файл налаштувань SOAR/BAS/Honey/інтеграцій")
    s.set_defaults(fn=lambda a: __import__("flyguard.listener", fromlist=["run"]).run(a))

    a = p.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main()
