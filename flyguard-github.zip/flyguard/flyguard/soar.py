"""FlySOAR — рефлекси мухи: плейбуки, черга дій на схвалення, журнал, TTL-блоки.

Безпека за замовчуванням:
  * auto_block вимкнено — усі дії лише після схвалення людини у веб-інтерфейсі;
  * навіть з auto_block блокування завжди має TTL (час життя) і знімається автоматично;
  * ліміт max_block_per_hour захищає від лавини блокувань;
  * білий список детектора поважається (кандидатами туди IP не потрапляють).

Дія — це крок: pending (чекає схвалення) -> approved/applied, або rejected/expired.
"""
from __future__ import annotations

import threading
import time
import urllib.request
import urllib.parse
from collections import deque

from . import integrations


class SoarEngine:
    def __init__(self, store, log_path: str = "soar_actions.jsonl"):
        self.store = store
        self.lock = threading.RLock()
        self.actions: deque = deque(maxlen=500)   # останні дії (dict)
        self._id = 0
        self.block_times: deque = deque(maxlen=1000)  # час застосованих блоків (для ліміту)
        self.active: dict[str, dict] = {}          # ip -> {expires, integration, action_id}
        self.log_path = log_path
        threading.Thread(target=self._ttl_loop, daemon=True).start()

    # ---------- конфіг ----------
    def cfg(self) -> dict:
        return self.store.get("soar")

    def integrations(self) -> dict:
        return self.store.get("integrations")

    # ---------- оцінка кандидата ----------
    def on_candidate(self, cand: dict):
        """Викликається, коли детектор позначив IP кандидатом. cand: ip, risk, hits, why, url."""
        c = self.cfg()
        if not c.get("enabled"):
            return
        for pb in c.get("playbooks", []):
            if not pb.get("enabled", True):
                continue
            if cand.get("risk", 0) < pb.get("min_risk", 0.99):
                continue
            if cand.get("hits", 0) < pb.get("min_hits", 1):
                continue
            self._spawn_action(pb, cand, c)
            break  # перший відповідний плейбук

    def _spawn_action(self, pb: dict, cand: dict, c: dict):
        with self.lock:
            self._id += 1
            ttl = int(pb.get("ttl_min", c.get("default_ttl_min", 240)))
            act = {"id": self._id, "ts": time.strftime("%Y-%m-%d %H:%M:%S"), "ip": cand["ip"],
                   "risk": cand.get("risk"), "playbook": pb.get("name", "?"),
                   "type": pb.get("action", "block"), "integration": pb.get("integration", ""),
                   "ttl_min": ttl, "status": "pending", "detail": ""}
            # сповіщення — завжди автоматично, це безпечно
            if act["type"] == "notify":
                self._notify(f"FlyGuard: підозрілий IP {cand['ip']} (ризик {cand.get('risk')}, "
                             f"плейбук {act['playbook']})", c)
                act["status"] = "done"
                act["detail"] = "сповіщення надіслано"
            elif pb.get("auto") and c.get("auto_block") and self._within_limit():
                self._apply(act, c)
            self.actions.appendleft(act)
            self._log(act)

    def _within_limit(self) -> bool:
        now = time.time()
        while self.block_times and now - self.block_times[0] > 3600:
            self.block_times.popleft()
        return len(self.block_times) < self.cfg().get("max_block_per_hour", 10)

    # ---------- застосування ----------
    def _apply(self, act: dict, c: dict):
        ints = self.integrations()
        icfg = ints.get(act["integration"])
        if not icfg:
            act["status"], act["detail"] = "error", "інтеграцію не знайдено"
            return
        dry = not bool(icfg.get("enabled")) or bool(icfg.get("dry_run", True))
        try:
            res = integrations.make(icfg).block(act["ip"], act["ttl_min"], dry)
        except ValueError as e:
            act["status"], act["detail"] = "error", str(e)
            return
        act["status"] = "applied" if res.get("ok") else "error"
        act["dry_run"] = res.get("dry_run", dry)
        act["detail"] = res.get("preview") or res.get("detail") or res.get("error", "")
        if res.get("ok"):
            self.block_times.append(time.time())
            self.active[act["ip"]] = {"expires": time.time() + act["ttl_min"] * 60,
                                      "integration": act["integration"], "action_id": act["id"]}
            if act.get("dry_run"):
                self._notify(f"FlyGuard (dry-run): блок {act['ip']} через {act['integration']} — "
                             f"перевірте і увімкніть застосування", c)

    def approve(self, action_id: int) -> dict:
        with self.lock:
            act = next((a for a in self.actions if a["id"] == action_id), None)
            if not act:
                return {"error": "дію не знайдено"}
            if act["status"] != "pending":
                return {"error": f"дія вже у статусі {act['status']}"}
            self._apply(act, self.cfg())
            self._log(act)
            return {"ok": True, "status": act["status"], "detail": act["detail"]}

    def reject(self, action_id: int) -> dict:
        with self.lock:
            act = next((a for a in self.actions if a["id"] == action_id), None)
            if not act:
                return {"error": "дію не знайдено"}
            act["status"] = "rejected"
            self._log(act)
            return {"ok": True}

    def unblock(self, ip: str) -> dict:
        with self.lock:
            info = self.active.pop(ip, None)
            if not info:
                return {"error": "активного блоку немає"}
            icfg = self.integrations().get(info["integration"])
            if icfg:
                dry = not bool(icfg.get("enabled")) or bool(icfg.get("dry_run", True))
                integrations.make(icfg).unblock(ip, dry)
            return {"ok": True}

    # ---------- TTL ----------
    def _ttl_loop(self):
        while True:
            time.sleep(30)
            now = time.time()
            for ip in [ip for ip, v in list(self.active.items()) if v["expires"] <= now]:
                try:
                    self.unblock(ip)
                    self._notify_plain(f"FlyGuard: блок {ip} знято за TTL")
                except Exception:
                    self.active.pop(ip, None)

    # ---------- сповіщення ----------
    def _notify(self, text: str, c: dict):
        n = c.get("notify", {})
        tok, chat = n.get("telegram_token"), n.get("telegram_chat")
        if not tok or not chat:
            return
        try:
            url = f"https://api.telegram.org/bot{tok}/sendMessage"
            data = urllib.parse.urlencode({"chat_id": chat, "text": text}).encode()
            urllib.request.urlopen(url, data=data, timeout=6)
        except Exception:
            pass

    def _notify_plain(self, text: str):
        self._notify(text, self.cfg())

    # ---------- журнал ----------
    def _log(self, act: dict):
        try:
            import json
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(act, ensure_ascii=False) + "\n")
        except OSError:
            pass

    def snapshot(self) -> dict:
        with self.lock:
            c = self.cfg()
            return {
                "enabled": c.get("enabled", False),
                "auto_block": c.get("auto_block", False),
                "playbooks": c.get("playbooks", []),
                "max_block_per_hour": c.get("max_block_per_hour", 10),
                "blocks_last_hour": len(self.block_times),
                "actions": list(self.actions)[:50],
                "active_blocks": [{"ip": ip, "integration": v["integration"],
                                   "expires_in_min": max(0, int((v["expires"] - time.time()) / 60))}
                                  for ip, v in self.active.items()],
                "pending": sum(1 for a in self.actions if a["status"] == "pending"),
            }
