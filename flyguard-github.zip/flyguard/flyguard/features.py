"""Перетворення запиту на «запах».

У мухи ~50 типів нюхових рецепторів (гломерул). Тут так само: кожен запит
описується вектором із 50 «нюхових каналів» — ознак вмісту запиту
та поведінки джерела (IP) у ковзному вікні часу.
"""
from __future__ import annotations

import math
import re
import zlib
from collections import defaultdict, deque
from datetime import datetime
from urllib.parse import unquote_plus, urlsplit, parse_qsl

import numpy as np

N_HASH = 14  # хешовані символьні триграми URL
CHANNELS = [
    "url_len", "path_depth", "n_params", "max_param_len", "query_entropy",
    "special_frac", "quotes", "angle_brackets", "sql_kw", "traversal",
    "pct_encoded", "cmd_inj", "sens_ext", "digit_frac", "upper_frac",
    "nonprint", "agent_len", "agent_empty", "agent_tool", "agent_browser",
    "m_get", "m_post", "m_other", "s2xx", "s3xx", "s4xx", "s5xx",
    "no_referer", "win_count", "win_uniq_url", "win_4xx", "since_last",
    "win_uniq_path", "win_post", "win_same_path", "hour_sin",
] + [f"tri_{i}" for i in range(N_HASH)]
N_CHANNELS = len(CHANNELS)  # 50

_SQL = re.compile(r"(union\s+select|select\s.+from|\bor\s+\d+=\d+|'\s*or\s*'|sleep\(|benchmark\(|"
                  r"information_schema|--\s|;--|/\*|xp_cmdshell|drop\s+table|waitfor\s+delay)", re.I)
_CMD = re.compile(r"(;\s*\w|`|\$\(|&&|\|\||\|\s*\w|/bin/|/etc/passwd|cmd\.exe|powershell)", re.I)
_EXT = re.compile(r"\.(env|git|bak|sql|ini|old|swp|config|htaccess|ds_store|log)(\b|$)|wp-admin|phpmyadmin|"
                  r"\.(asp|aspx|jsp|cgi)\b", re.I)
_TOOLS = re.compile(r"sqlmap|nikto|nmap|masscan|zgrab|nuclei|dirbuster|gobuster|wfuzz|hydra|"
                    r"python-requests|curl/|wget/|go-http-client|libwww|scanner|acunetix|nessus", re.I)


def _entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = defaultdict(int)
    for ch in s:
        counts[ch] += 1
    n = len(s)
    return -sum(c / n * math.log2(c / n) for c in counts.values())


def _ts(rec: dict) -> float:
    d, t = rec.get("date", ""), rec.get("time", "")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(f"{d} {t}".strip(), fmt).timestamp()
        except ValueError:
            pass
    return float("nan")


def content_features(rec: dict) -> np.ndarray:
    url = rec.get("url", "") or "/"
    dec = unquote_plus(unquote_plus(url))
    parts = urlsplit(dec if dec.startswith("/") else "/" + dec)
    path, query = parts.path, parts.query
    params = parse_qsl(query, keep_blank_values=True)
    agent = rec.get("agent", "")
    method = rec.get("method", "GET")
    try:
        code = int(rec.get("retcode") or 0)
    except ValueError:
        code = 0
    n = max(len(dec), 1)
    v = [
        math.log1p(len(url)),
        path.count("/"),
        math.log1p(len(params)),
        math.log1p(max((len(p[1]) for p in params), default=0)),
        _entropy(query),
        sum(not c.isalnum() and c not in "/.-_=&?" for c in dec) / n,
        dec.count("'") + dec.count('"'),
        dec.count("<") + dec.count(">"),
        len(_SQL.findall(dec)),
        dec.count("../") + dec.count("..\\"),
        math.log1p(url.count("%")),
        len(_CMD.findall(dec)),
        float(bool(_EXT.search(dec))),
        sum(c.isdigit() for c in dec) / n,
        sum(c.isupper() for c in dec) / n,
        sum(not c.isprintable() for c in dec),
        math.log1p(len(agent)),
        float(not agent),
        float(bool(_TOOLS.search(agent))),
        float("mozilla" in agent.lower()),
        float(method == "GET"),
        float(method == "POST"),
        float(method not in ("GET", "POST", "")),
        float(200 <= code < 300),
        float(300 <= code < 400),
        float(400 <= code < 500),
        float(code >= 500),
        float(not rec.get("referer")),
    ]
    return np.array(v, dtype=np.float32)


def trigram_hash(rec: dict) -> np.ndarray:
    s = unquote_plus(rec.get("url", "")).lower()
    h = np.zeros(N_HASH, dtype=np.float32)
    for i in range(len(s) - 2):
        h[zlib.crc32(s[i:i + 3].encode()) % N_HASH] += 1
    return np.log1p(h)


class BehaviorTracker:
    """Поведінка IP у ковзному вікні (за замовчуванням 60 с)."""

    def __init__(self, window: float = 60.0):
        self.window = window
        self.hist = defaultdict(deque)  # src -> deque[(ts, path, code, method)]
        self._clock = 0.0

    def update(self, rec: dict) -> np.ndarray:
        ts = _ts(rec)
        if math.isnan(ts):  # немає часу -> умовний лічильник
            self._clock += 1.0
            ts = self._clock
        src = rec.get("src", "?")
        q = self.hist[src]
        last = q[-1][0] if q else None
        path = urlsplit(rec.get("url", "/") or "/").path
        try:
            code = int(rec.get("retcode") or 0)
        except ValueError:
            code = 0
        q.append((ts, path, code, rec.get("method", "")))
        self._n = getattr(self, "_n", 0) + 1
        if self._n % 20000 == 0:  # прибрати IP, що давно мовчать (інакше пам'ять росте)
            for ip in [ip for ip, d in self.hist.items() if d and ts - d[-1][0] > self.window * 10]:
                del self.hist[ip]
        while q and ts - q[0][0] > self.window:
            q.popleft()
        n = len(q)
        urls = {e[1] for e in q}
        same = sum(e[1] == path for e in q) / n
        hour = datetime.fromtimestamp(ts).hour if ts > 1e6 else 12
        return np.array([
            math.log1p(n),
            len(urls) / n,
            sum(400 <= e[2] < 500 for e in q) / n,
            math.log1p(max(ts - last, 0.0)) if last is not None else math.log1p(self.window),
            math.log1p(len(urls)),
            sum(e[3] == "POST" for e in q) / n,
            same,
            math.sin(2 * math.pi * hour / 24),
        ], dtype=np.float32)


def featurize(records, tracker: BehaviorTracker | None = None) -> np.ndarray:
    tracker = tracker or BehaviorTracker()
    rows = [np.concatenate([content_features(r), tracker.update(r), trigram_hash(r)]) for r in records]
    X = np.vstack(rows) if rows else np.zeros((0, N_CHANNELS), np.float32)
    assert X.shape[1] == N_CHANNELS, X.shape
    return X


# ================= Мережева муха: ознаки з'єднань (Check Point / FortiGate) =================
NET_CHANNELS = [
    "proto_tcp", "proto_udp", "proto_other", "dport_log", "high_port", "wellknown_port",
    "ephemeral_dport", "act_deny", "act_accept", "src_private", "src_external", "dst_private",
    "z_ext_local", "z_ext_int", "z_int_int", "svc_unknown",
    # поведінка джерела у вікні
    "win_count", "win_uniq_dport", "win_uniq_dst", "win_deny_ratio",
    "dport_fanout", "dst_fanout", "port_entropy", "since_last", "hour_sin",
]
N_NET = len(NET_CHANNELS)  # 25

WELLKNOWN = {22, 23, 25, 53, 80, 110, 123, 143, 161, 389, 443, 445, 465, 514, 587,
             636, 993, 995, 1433, 1521, 3306, 3389, 5432, 5900, 8080, 8443}


def _is_private(ip: str) -> bool:
    import ipaddress
    try:
        a = ipaddress.ip_address(ip.split("%")[0])
        return a.is_private or a.is_loopback
    except ValueError:
        return False


def _port(v) -> int:
    try:
        return int(str(v))
    except (ValueError, TypeError):
        return 0


class NetTracker:
    """Поведінка джерела у з'єднаннях (вікно за замовчуванням 120 с).
    Ловить сканування портів (одне джерело -> багато портів) і підбір (повтор на один порт)."""

    def __init__(self, window: float = 120.0):
        self.window = window
        self.hist = defaultdict(deque)   # src -> deque[(ts, dst, dport, deny)]
        self._clock = 0.0
        self._n = 0

    def update(self, rec: dict) -> np.ndarray:
        ts = _ts(rec)
        if math.isnan(ts):
            self._clock += 1.0
            ts = self._clock
        src = rec.get("src", "?")
        dport = _port(rec.get("dport"))
        deny = int(any(a in rec.get("action", "").lower()
                       for a in ("drop", "deny", "block", "reject")))
        q = self.hist[src]
        last = q[-1][0] if q else None
        q.append((ts, rec.get("dst", ""), dport, deny))
        self._n += 1
        if self._n % 20000 == 0:
            for ip in [ip for ip, d in self.hist.items() if d and ts - d[-1][0] > self.window * 10]:
                del self.hist[ip]
        while q and ts - q[0][0] > self.window:
            q.popleft()
        n = len(q)
        dports = {e[2] for e in q}
        dsts = {e[1] for e in q}
        denies = sum(e[3] for e in q)
        # ентропія розподілу портів: висока = перебір багатьох різних портів
        from collections import Counter
        cnt = Counter(e[2] for e in q)
        ent = -sum(c / n * math.log2(c / n) for c in cnt.values()) if n else 0.0
        hour = datetime.fromtimestamp(ts).hour if ts > 1e6 else 12
        return np.array([
            math.log1p(n),
            len(dports) / n,
            len(dsts) / n,
            denies / n,
            math.log1p(len(dports)),       # абсолютний fan-out портів
            math.log1p(len(dsts)),         # fan-out адрес (sweep)
            ent,
            math.log1p(max(ts - last, 0.0)) if last is not None else math.log1p(self.window),
            math.sin(2 * math.pi * hour / 24),
        ], dtype=np.float32)


def net_static(rec: dict) -> np.ndarray:
    proto = str(rec.get("proto", "")).lower()
    tcp = proto in ("6", "tcp")
    udp = proto in ("17", "udp")
    dport = _port(rec.get("dport"))
    act = rec.get("action", "").lower()
    deny = any(a in act for a in ("drop", "deny", "block", "reject"))
    acc = "accept" in act or "allow" in act or "decrypt" in act
    inz, outz = rec.get("inzone", "").lower(), rec.get("outzone", "").lower()
    svc = rec.get("service_id", "").lower()
    return np.array([
        float(tcp), float(udp), float(not tcp and not udp),
        math.log1p(dport), float(dport > 1024), float(dport in WELLKNOWN),
        float(dport >= 32768),
        float(deny), float(acc),
        float(_is_private(rec.get("src", ""))), float(not _is_private(rec.get("src", ""))),
        float(_is_private(rec.get("dst", ""))),
        float(inz == "external" and outz == "local"),
        float(inz == "external" and outz == "internal"),
        float(inz == "internal" and outz == "internal"),
        float(svc in ("", "unknown", "tcp-high-ports", "other")),
    ], dtype=np.float32)


def net_features(rec: dict) -> np.ndarray:
    pass  # зручний алиас нижче


def neturize(records, tracker: "NetTracker | None" = None) -> np.ndarray:
    tracker = tracker or NetTracker()
    rows = [np.concatenate([net_static(r), tracker.update(r)]) for r in records]
    X = np.vstack(rows) if rows else np.zeros((0, N_NET), np.float32)
    assert X.shape[1] == N_NET, X.shape
    return X
