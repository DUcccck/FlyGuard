"""Модель грибоподібного тіла (mushroom body) дрозофіли.

Біологія → код:
  * Проєкційні нейрони (PN)                 -> 50 каналів запиту, кожен розщеплений на
                                              ON/OFF-нейрони («більше/менше за норму»)
  * Клітини Кеньона (KC, ~2000)            -> розріджена випадкова проєкція: кожна KC
                                              «слухає» ~6 випадкових PN
  * APL-нейрон (гальмування)                -> winner-take-all: активні лише top-5% KC
  * MBON «новизни»                          -> сила відповіді KC-переможців: звичний
                                              «запах» майже не збуджує KC, незвичний —
                                              збуджує сильно (калібровано на нормі)
  * Дофамін + MBON «уникати/наближатись»     -> асоціативне навчання: KC, активні на
                                              запитах, які FortiWeb заблокував,
                                              пов'язуються з «небезпекою»

Посилання: Dasgupta, Stevens, Navlakha. "A neural algorithm for a fundamental computing
problem", Science 2017;  Dasgupta et al. "A neural data structure for novelty detection",
PNAS 2018.
"""
from __future__ import annotations

import numpy as np


class MushroomBody:
    def __init__(self, n_pn: int, n_kc: int = 2000, pn_per_kc: int = 6,
                 sparsity: float = 0.05, seed: int = 42):
        rng = np.random.default_rng(seed)
        self.n_pn, self.n_kc = n_pn, n_kc
        self.k = max(1, int(round(n_kc * sparsity)))
        # бінарна розріджена матриця PN(ON+OFF) -> KC
        self.W = np.zeros((n_kc, 2 * n_pn), dtype=np.float32)
        for i in range(n_kc):
            self.W[i, rng.choice(2 * n_pn, size=pn_per_kc, replace=False)] = 1.0
        self.bias = rng.uniform(0, 1e-3, n_kc).astype(np.float32)  # розрив нічиїх
        self.med = np.zeros(n_pn, np.float32)
        self.scale = np.ones(n_pn, np.float32)
        # лічильники для MBON
        self.kc_seen = np.zeros(n_kc, np.float64)   # новизна
        self.kc_bad = np.zeros(n_kc, np.float64)    # дофамін «покарання»
        self.kc_good = np.zeros(n_kc, np.float64)   # «звичайне»
        self.n_seen = self.n_bad = self.n_good = 0
        self.calib = np.array([0.0, 1.0])           # розподіл новизни на навчанні

    # ---------- PN: нормалізація (адаптація рецепторів) ----------
    def fit_normalizer(self, X: np.ndarray) -> None:
        self.med = np.median(X, axis=0).astype(np.float32)
        q75, q25 = np.percentile(X, [75, 25], axis=0)
        iqr = (q75 - q25).astype(np.float32)
        std = X.std(axis=0).astype(np.float32)
        self.scale = np.where(iqr > 1e-6, iqr, np.where(std > 1e-6, std, 1.0)).astype(np.float32)

    def pn(self, X: np.ndarray) -> np.ndarray:
        Z = (X - self.med) / self.scale
        Z = np.clip(Z, -10, 10)
        return np.hstack([np.maximum(Z, 0), np.maximum(-Z, 0)])  # ON / OFF

    # ---------- KC: розширення + winner-take-all ----------
    def _kc(self, X: np.ndarray):
        # блоками по 4096 запитів: інакше 200 тис. x 2000 KC = 1.6 ГБ пам'яті
        Ts, Ds = [], []
        for i in range(0, max(len(X), 1), 4096):
            A = self.pn(X[i:i + 4096]) @ self.W.T + self.bias
            T = np.argpartition(-A, self.k - 1, axis=1)[:, : self.k]
            Ts.append(T.astype(np.int32))
            Ds.append(np.take_along_axis(A, T, axis=1).mean(axis=1))
        return np.vstack(Ts), np.concatenate(Ds)

    def tags(self, X: np.ndarray) -> np.ndarray:
        """Індекси активних KC (winner-take-all), shape (n, k)."""
        return self._kc(X)[0]

    # ---------- навчання ----------
    def learn(self, X: np.ndarray, y: np.ndarray | None = None) -> "MushroomBody":
        T, drive = self._kc(X)
        if y is None:
            y = np.zeros(len(X), dtype=int)
        normal = T[y == 0]
        np.add.at(self.kc_seen, normal.ravel(), 1)
        np.add.at(self.kc_good, normal.ravel(), 1)
        np.add.at(self.kc_bad, T[y == 1].ravel(), 1)
        self.n_seen += len(normal)
        self.n_good += int((y == 0).sum())
        self.n_bad += int((y == 1).sum())
        # калібрування: розподіл новизни на звичайному трафіку
        self.calib = np.sort(drive[y == 0]) if (y == 0).any() else np.array([0.0, 1.0])
        return self

    def fit(self, X: np.ndarray, y: np.ndarray | None = None) -> "MushroomBody":
        normal = X if y is None else X[y == 0]
        self.fit_normalizer(normal if len(normal) > 10 else X)
        return self.learn(X, y)

    # ---------- MBON-и ----------
    def novelty(self, X: np.ndarray) -> np.ndarray:
        """0..1 — перцентиль новизни відносно звичайного трафіку."""
        raw = self._kc(X)[1]
        return np.searchsorted(self.calib, raw, side="right") / max(len(self.calib), 1)

    def danger(self, X: np.ndarray) -> np.ndarray | None:
        """0..1 — наскільки «запах» схожий на те, що вже карали дофаміном."""
        if self.n_bad == 0:
            return None
        T = self.tags(X)
        pb = (self.kc_bad[T] / self.n_bad).mean(axis=1)
        pg = (self.kc_good[T] / max(self.n_good, 1)).mean(axis=1)
        return pb / (pb + pg + 1e-9)

    def risk(self, X: np.ndarray, novelty_weight: float = 1.0) -> np.ndarray:
        nov = self.novelty(X) ** 4 * novelty_weight  # підсилюємо лише хвіст розподілу
        d = self.danger(X)
        if d is None:
            return nov
        return 1 - (1 - d) * (1 - nov)

    def trace(self, x: np.ndarray, channels: list[str], max_links: int = 6) -> dict:
        """Повний «знімок мозку» для одного запиту — для візуалізації у веб-інтерфейсі."""
        X = x.reshape(1, -1)
        z = np.clip((x - self.med) / self.scale, -10, 10)
        pn = self.pn(X)[0]
        A = pn @ self.W.T + self.bias
        active = np.argpartition(-A, self.k - 1)[: self.k]
        active = active[np.argsort(-A[active])]
        # асоціація кожної активної KC: 1 — бачили на атаках, 0 — на нормальному трафіку
        pb = self.kc_bad[active] / max(self.n_bad, 1)
        pg = self.kc_good[active] / max(self.n_good, 1)
        assoc = np.where(pb + pg > 0, pb / (pb + pg + 1e-12), 0.5)
        nov = float(self.novelty(X)[0])
        d = self.danger(X)
        # зв'язки: найзбудженіші рецептори -> активні KC, які їх «слухають»
        top_ch = [int(i) for i in np.argsort(-np.abs(z))[:max_links] if abs(z[i]) > 0.5]
        n = self.n_pn
        links = []
        for c in top_ch:
            col = c if z[c] > 0 else c + n  # ON- чи OFF-нейрон
            kcs = [int(k) for k in active if self.W[k, col] > 0]
            links.append({"ch": c, "kcs": kcs})
        return {
            "channels": channels,
            "z": [round(float(v), 2) for v in z],
            "x": [round(float(v), 3) for v in x],
            "n_kc": int(self.n_kc), "k": int(self.k),
            "active": [int(i) for i in active],
            "drive": [round(float(v), 2) for v in A[active]],
            "assoc": [round(float(v), 3) for v in assoc],
            "links": links,
            "novelty": round(nov, 4),
            "novelty_term": round(nov ** 4, 4),
            "danger": None if d is None else round(float(d[0]), 4),
            "risk": round(float(self.risk(X)[0]), 4),
        }

    def explain(self, x: np.ndarray, channels: list[str], top: int = 3) -> list[str]:
        """Які канали «пахнуть» найнезвичніше (для аналітика SOC)."""
        z = np.abs(((x - self.med) / self.scale))
        idx = np.argsort(-z)[:top]
        return [f"{channels[i]}={x[i]:.2f}" for i in idx if z[i] > 1.5]

    # ---------- збереження ----------
    def save(self, path: str) -> None:
        np.savez_compressed(path, **{k: v for k, v in self.__dict__.items()
                                     if isinstance(v, (np.ndarray, int, float))})

    @classmethod
    def load(cls, path: str) -> "MushroomBody":
        d = np.load(path)
        mb = cls.__new__(cls)
        for k in d.files:
            v = d[k]
            setattr(mb, k, v.item() if v.ndim == 0 else v)
        return mb
