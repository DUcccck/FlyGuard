"""Інтеграції з мережевими пристроями: FortiGate, FortiWeb, Check Point.

Кожна інтеграція вміє block_ip / unblock_ip / test. За замовчуванням dry_run=True:
нічого на пристрої не змінюється, а повертається опис дії (і готова CLI-команда).
Реальний виклик API виконується лише коли в налаштуваннях знято dry-run і задано доступ.

Використовує лише стандартну бібліотеку (urllib). У середовищах без доступу до пристрою
всі виклики все одно безпечні: при помилці повертається ok=False з описом.
"""
from __future__ import annotations

import json
import ssl
import urllib.error
import urllib.request

TIMEOUT = 8


def _http(method: str, url: str, headers: dict | None = None, body=None, verify_tls: bool = True):
    ctx = None
    if url.lower().startswith("https"):
        ctx = ssl.create_default_context()
        if not verify_tls:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    with urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx) as r:
        raw = r.read().decode("utf-8", "replace")
        try:
            return r.status, json.loads(raw)
        except json.JSONDecodeError:
            return r.status, raw


class Integration:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.name = cfg.get("name", "?")
        self.kind = cfg.get("kind", "?")
        self.host = cfg.get("host", "").rstrip("/")
        self.verify = bool(cfg.get("verify_tls", False))
        self.group = cfg.get("group", "flyguard-block")

    def _base(self) -> str:
        h = self.host
        return h if h.startswith("http") else "https://" + h

    # --- підкласи перевизначають ці три ---
    def test(self) -> dict:
        raise NotImplementedError

    def _do_block(self, ip: str, ttl_min: int) -> dict:
        raise NotImplementedError

    def _do_unblock(self, ip: str) -> dict:
        raise NotImplementedError

    def preview(self, ip: str, ttl_min: int) -> str:
        """Текст того, що буде зроблено (для dry-run і журналу)."""
        return f"{self.kind}:{self.name} заблокувати {ip} на {ttl_min} хв"

    def block(self, ip: str, ttl_min: int, dry_run: bool) -> dict:
        if dry_run:
            return {"ok": True, "dry_run": True, "preview": self.preview(ip, ttl_min)}
        try:
            return {"ok": True, "dry_run": False, **self._do_block(ip, ttl_min)}
        except (urllib.error.URLError, OSError, ValueError) as e:
            return {"ok": False, "error": str(e), "preview": self.preview(ip, ttl_min)}

    def unblock(self, ip: str, dry_run: bool) -> dict:
        if dry_run:
            return {"ok": True, "dry_run": True, "preview": f"{self.kind}:{self.name} розблокувати {ip}"}
        try:
            return {"ok": True, "dry_run": False, **self._do_unblock(ip)}
        except (urllib.error.URLError, OSError, ValueError) as e:
            return {"ok": False, "error": str(e)}


class FortiGate(Integration):
    """FortiOS REST API: додавання IP до адресної групи, яку блокує політика.
    Потрібен API-токен (System > Administrators > REST API Admin)."""

    def _hdr(self):
        return {"Authorization": f"Bearer {self.cfg.get('token','')}", "Content-Type": "application/json"}

    def test(self) -> dict:
        try:
            st, _ = _http("GET", f"{self._base()}/api/v2/monitor/system/status",
                          self._hdr(), verify_tls=self.verify)
            if st != 200:
                return {"ok": False, "status": st, "note": "перевірте API-токен і Trusted Hosts"}
            # з'єднання ок — перевіряємо, чи існує група блокування
            try:
                gst, _ = _http("GET", f"{self._base()}/api/v2/cmdb/firewall/addrgrp/{self.group}",
                               self._hdr(), verify_tls=self.verify)
                if gst == 404:
                    return {"ok": False, "status": 404,
                            "note": f"з'єднання ОК, але групи «{self.group}» нема — створіть її на FortiGate"}
            except (urllib.error.URLError, OSError):
                pass
            return {"ok": True, "status": 200}
        except (urllib.error.URLError, OSError) as e:
            return {"ok": False, "error": str(e)}

    def preview(self, ip, ttl_min):
        return (f"FortiGate {self.name}: створити адресу flyguard_{ip}, додати в групу «{self.group}» "
                f"(політика deny має блокувати цю групу); зняти через {ttl_min} хв")

    def _do_block(self, ip, ttl_min):
        base, hdr = self._base(), self._hdr()
        name = f"flyguard_{ip}"
        _http("POST", f"{base}/api/v2/cmdb/firewall/address",
              hdr, {"name": name, "subnet": f"{ip} 255.255.255.255",
                    "comment": "FlyGuard auto-block"}, self.verify)
        _http("POST", f"{base}/api/v2/cmdb/firewall/addrgrp/{self.group}/member",
              hdr, {"name": name}, self.verify)
        return {"detail": f"IP додано до групи {self.group}"}

    def _do_unblock(self, ip):
        base, hdr = self._base(), self._hdr()
        name = f"flyguard_{ip}"
        _http("DELETE", f"{base}/api/v2/cmdb/firewall/addrgrp/{self.group}/member/{name}", hdr, None, self.verify)
        _http("DELETE", f"{base}/api/v2/cmdb/firewall/address/{name}", hdr, None, self.verify)
        return {"detail": "IP прибрано з групи"}


class FortiWeb(Integration):
    """FortiWeb: IP List (black-ip). Через API або готова CLI-команда."""

    def _hdr(self):
        import base64
        tok = self.cfg.get("token", "")
        if not tok and self.cfg.get("user"):
            tok = base64.b64encode(f"{self.cfg['user']}:{self.cfg.get('password','')}".encode()).decode()
        return {"Authorization": tok, "Content-Type": "application/json"}

    def test(self) -> dict:
        try:
            st, _ = _http("GET", f"{self._base()}/api/v2.0/system/status.systemstatus",
                          self._hdr(), verify_tls=self.verify)
            return {"ok": st == 200, "status": st}
        except (urllib.error.URLError, OSError) as e:
            return {"ok": False, "error": str(e)}

    def preview(self, ip, ttl_min):
        from .cli import _fortiweb_cli
        return "CLI для FortiWeb:\n" + _fortiweb_cli([ip], self.group)

    def _do_block(self, ip, ttl_min):
        # REST-схема IP List відрізняється між версіями; повертаємо CLI як надійний шлях
        return {"detail": "застосуйте CLI вручну (див. preview) або налаштуйте REST під вашу версію",
                "cli": self.preview(ip, ttl_min)}

    def _do_unblock(self, ip):
        return {"detail": f"видаліть {ip} з IP List «{self.group}» у FortiWeb"}


class CheckPoint(Integration):
    """Check Point: додавання IP у Network Group через Web API (login -> sid -> add-host/set-group).
    На Quantum Spark (SMB) Web API часто недоступний — тоді лишається ручний спосіб."""

    def _login(self):
        st, r = _http("POST", f"{self._base()}/web_api/login", {"Content-Type": "application/json"},
                      {"user": self.cfg.get("user", ""), "password": self.cfg.get("password", "")}, self.verify)
        if st != 200 or "sid" not in r:
            raise ValueError("не вдалося увійти у Check Point Web API")
        return r["sid"]

    def _hdr(self, sid):
        return {"X-chkp-sid": sid, "Content-Type": "application/json"}

    def test(self) -> dict:
        try:
            sid = self._login()
            _http("POST", f"{self._base()}/web_api/logout", self._hdr(sid), {}, self.verify)
            return {"ok": True}
        except (urllib.error.URLError, OSError, ValueError) as e:
            return {"ok": False, "error": str(e), "note": "на Spark/SMB Web API може бути недоступний"}

    def preview(self, ip, ttl_min):
        return (f"Check Point {self.name}: додати host flyguard_{ip} у групу «{self.group}», "
                f"опублікувати (publish); зняти через {ttl_min} хв. "
                f"На Spark Web API може бути вимкнений — тоді додайте вручну.")

    def _do_block(self, ip, ttl_min):
        sid = self._login()
        try:
            h = self._hdr(sid)
            _http("POST", f"{self._base()}/web_api/add-host", h,
                  {"name": f"flyguard_{ip}", "ip-address": ip}, self.verify)
            _http("POST", f"{self._base()}/web_api/set-group", h,
                  {"name": self.group, "members": {"add": f"flyguard_{ip}"}}, self.verify)
            _http("POST", f"{self._base()}/web_api/publish", h, {}, self.verify)
        finally:
            _http("POST", f"{self._base()}/web_api/logout", self._hdr(sid), {}, self.verify)
        return {"detail": f"host додано у групу {self.group} і опубліковано"}

    def _do_unblock(self, ip):
        sid = self._login()
        try:
            h = self._hdr(sid)
            _http("POST", f"{self._base()}/web_api/set-group", h,
                  {"name": self.group, "members": {"remove": f"flyguard_{ip}"}}, self.verify)
            _http("POST", f"{self._base()}/web_api/publish", h, {}, self.verify)
        finally:
            _http("POST", f"{self._base()}/web_api/logout", self._hdr(sid), {}, self.verify)
        return {"detail": "host прибрано з групи"}


_KINDS = {"fortigate": FortiGate, "fortiweb": FortiWeb, "checkpoint": CheckPoint}


def make(cfg: dict) -> Integration:
    kind = cfg.get("kind", "").lower()
    cls = _KINDS.get(kind)
    if not cls:
        raise ValueError(f"невідома інтеграція: {kind}")
    return cls(cfg)
