"""Веб-інтерфейс FlyGuard (без зовнішніх залежностей, лише стандартна бібліотека).

Безпека:
  * HTTP Basic-автентифікація (логін: admin). Якщо пароль не задано — генерується і друкується в консоль.
  * Слухає лише 127.0.0.1. Доступ з мережі — через reverse proxy з HTTPS (nginx, див. nginx/flyguard.conf).
  * Захист від CSRF: POST-запити приймаються лише із заголовком X-FlyGuard.
  * URL-адреси атак показуються лише як текст (textContent) + суворий CSP, тож XSS-пейлоади
    з логів не виконаються у вашому браузері.
"""
from __future__ import annotations

import base64
import hmac
import ipaddress
import json
import os
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

_HTML_PATH = os.path.join(os.path.dirname(__file__), "web_index.html")
MAX_BODY = 4096


def _valid_ip(ip) -> bool:
    try:
        ipaddress.ip_address(str(ip))
        return True
    except ValueError:
        return False


def start_web(app, host: str, port: int, password: str):
    if not password:
        password = secrets.token_urlsafe(12)
        print(f"Веб-інтерфейс: згенеровано пароль  admin / {password}  "
              f"(задайте свій через --web-password або FLYGUARD_WEB_PASSWORD)", flush=True)
    expected = "Basic " + base64.b64encode(f"admin:{password}".encode()).decode()

    class H(BaseHTTPRequestHandler):
        server_version = "FlyGuard"
        sys_version = ""

        def log_message(self, *args):  # не засмічувати консоль
            pass

        # ---- допоміжне ----
        def _auth(self) -> bool:
            got = self.headers.get("Authorization", "")
            if hmac.compare_digest(got.encode(), expected.encode()):
                return True
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="FlyGuard", charset="UTF-8"')
            self.send_header("Content-Length", "0")
            self.end_headers()
            return False

        def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _json(self, obj, code=200):
            self._send(code, json.dumps(obj, ensure_ascii=False).encode(), "application/json; charset=utf-8")

        # ---- GET ----
        def do_GET(self):
            if not self._auth():
                return
            u = urlsplit(self.path)
            if u.path == "/":
                nonce = secrets.token_urlsafe(16)
                html = open(_HTML_PATH, encoding="utf-8").read()
                body = html.replace("__NONCE__", nonce).encode()
                csp = (f"default-src 'none'; script-src 'nonce-{nonce}'; style-src 'unsafe-inline'; "
                       "connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'; "
                       "frame-ancestors 'none'")
                self._send(200, body, "text/html; charset=utf-8", {"Content-Security-Policy": csp})
            elif u.path == "/api/state":
                self._json(app.state())
            elif u.path == "/api/brain":
                det = app.det
                if det is None:
                    return self._json({"error": "муха ще навчається"}, 409)
                q = parse_qs(u.query)
                aid = q.get("alert", [None])[0]
                fly = q.get("fly", ["web"])[0]
                if fly not in ("web", "net"):
                    fly = "web"
                try:
                    aid = int(aid) if aid not in (None, "") else None
                except ValueError:
                    aid = None
                t = det.brain(aid, fly)
                self._json(t if t else {"error": "ще немає запитів"}, 200 if t else 404)
            elif u.path == "/api/fortiweb.txt":
                from .cli import _fortiweb_cli
                scope = parse_qs(u.query).get("scope", ["approved"])[0]
                det = app.det
                ips = [] if not det else (sorted(det.approved) if scope == "approved" else list(det.blocked))
                ips = [ip for ip in ips if _valid_ip(ip)]
                body = (_fortiweb_cli(ips) + "\n").encode() if ips else b"# list is empty\n"
                self._send(200, body, "text/plain; charset=utf-8",
                           {"Content-Disposition": f'attachment; filename="flyguard-{scope}.txt"'})
            elif u.path == "/api/bas":
                self._json(app.bas.snapshot())
            else:
                self._json({"error": "not found"}, 404)

        # ---- POST ----
        def do_POST(self):
            if not self._auth():
                return
            if self.headers.get("X-FlyGuard") != "1":
                return self._json({"error": "missing X-FlyGuard header"}, 403)
            try:
                n = int(self.headers.get("Content-Length") or 0)
                data = json.loads(self.rfile.read(min(n, MAX_BODY)) or b"{}")
            except (ValueError, json.JSONDecodeError):
                return self._json({"error": "bad json"}, 400)
            path = urlsplit(self.path).path
            det = app.det

            if path == "/api/train":
                return self._json({"message": app.train_async()})
            # ---- FlySOAR ----
            if path == "/api/soar/config":
                app.store.update("soar", {k: data[k] for k in
                                 ("enabled", "auto_block", "max_block_per_hour", "default_ttl_min")
                                 if k in data})
                if "notify" in data:
                    app.store.update("soar", {"notify": data["notify"]})
                return self._json({"ok": True})
            if path == "/api/soar/playbooks":
                if not isinstance(data.get("playbooks"), list):
                    return self._json({"error": "playbooks має бути списком"}, 400)
                app.store.update("soar", {"playbooks": data["playbooks"][:50]})
                return self._json({"ok": True})
            if path == "/api/soar/approve":
                return self._json(app.soar.approve(int(data.get("id", -1))))
            if path == "/api/soar/reject":
                return self._json(app.soar.reject(int(data.get("id", -1))))
            if path == "/api/soar/unblock":
                ip = str(data.get("ip", ""))
                return self._json(app.soar.unblock(ip) if _valid_ip(ip) else {"error": "невірний IP"})
            # ---- Інтеграції ----
            if path == "/api/integrations/save":
                it = data.get("integration") or {}
                name = str(it.get("name", "")).strip()
                if not name or it.get("kind") not in ("fortigate", "fortiweb", "checkpoint"):
                    return self._json({"error": "вкажіть name і kind"}, 400)
                ints = app.store.get("integrations")
                cur = ints.get(name, {})
                for k in ("token", "password"):          # не затирати секрет маскою ••••
                    if it.get(k, "").startswith("••••"):
                        it[k] = cur.get(k, "")
                ints[name] = it
                app.store.set_section("integrations", ints)
                return self._json({"ok": True})
            if path == "/api/integrations/delete":
                ints = app.store.get("integrations")
                ints.pop(str(data.get("name", "")), None)
                app.store.set_section("integrations", ints)
                return self._json({"ok": True})
            if path == "/api/integrations/test":
                from . import integrations as I
                icfg = app.store.get("integrations").get(str(data.get("name", "")))
                if not icfg:
                    return self._json({"error": "інтеграцію не знайдено"}, 404)
                try:
                    return self._json(I.make(icfg).test())
                except ValueError as e:
                    return self._json({"error": str(e)}, 400)
            # ---- FlyBAS ----
            if path == "/api/bas/config":
                patch = {}
                if "target" in data:
                    patch["target"] = str(data["target"]).strip()
                if isinstance(data.get("allow_nets"), list):
                    patch["allow_nets"] = data["allow_nets"]
                app.store.update("bas", patch)
                return self._json({"ok": True})
            if path == "/api/bas/run":
                return self._json(app.bas.run_async(data.get("target") or None))
            # ---- FlyHoney ----
            if path == "/api/honey/config":
                patch = {}
                if "enabled" in data:
                    patch["enabled"] = bool(data["enabled"])
                if "feed_soar" in data:
                    patch["feed_soar"] = bool(data["feed_soar"])
                if isinstance(data.get("ports"), list):
                    patch["ports"] = [int(p) for p in data["ports"] if 1 <= int(p) <= 65535][:20]
                app.store.update("honey", patch)
                app.honey.restart()
                return self._json({"ok": True, "listening": app.honey.snapshot()["listening"]})
            if det is None:
                return self._json({"error": "муха ще навчається"}, 409)
            if path in ("/api/approve", "/api/reject"):
                ip = str(data.get("ip", ""))
                if not _valid_ip(ip):
                    return self._json({"error": "невірний IP"}, 400)
                if path == "/api/approve":
                    det.approve(ip)
                else:
                    det.reject(ip, whitelist=bool(data.get("whitelist")))
                return self._json({"ok": True})
            if path == "/api/threshold":
                try:
                    det.set_threshold(float(data.get("value")))
                except (TypeError, ValueError):
                    return self._json({"error": "невірне значення"}, 400)
                return self._json({"ok": True, "threshold": det.thr})
            return self._json({"error": "not found"}, 404)

    srv = ThreadingHTTPServer((host, port), H)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    shown = "localhost" if host in ("127.0.0.1", "0.0.0.0") else host
    print(f"Веб-інтерфейс: http://{shown}:{port}  (логін admin)", flush=True)
    return srv
