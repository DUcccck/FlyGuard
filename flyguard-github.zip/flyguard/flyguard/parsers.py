"""Парсери логів FortiWeb і Check Point (Quantum Spark / Log Exporter).

Підтримує:
  * syslog / "raw" формат FortiWeb:  date=2026-10-01 time=12:00:01 type=attack src=1.2.3.4 http_url="/a?b=1" ...
  * syslog Check Point:  ... [action:"Accept"; src:"1.2.3.4"; resource:"https://site/a?b=1"; product:"URL Filtering"; ...]
  * CSV-експорт (перший рядок — заголовки)
  * JSON / JSON Lines (наприклад, з ELK/Wazuh/Splunk), у т.ч. вкладені поля

Назви полів у різних версіях FortiWeb / SIEM можуть відрізнятися,
тому всі поля зводяться до канонічних імен через ALIASES.
"""
from __future__ import annotations

import csv
import json
import re
from typing import Dict, Iterable, Iterator

# key=value або key="value with spaces"
_KV_RE = re.compile(r'(\w[\w.\-]*)=("(?:[^"\\]|\\.)*"|\S*)')
# Check Point: key:"value"; key:"value"
_CP_RE = re.compile(r'(\w[\w.\-]*):"((?:[^"\\]|\\.)*)"')

# канонічне ім'я -> можливі назви в логах (нижній регістр)
ALIASES: Dict[str, tuple] = {
    "date":      ("date",),
    "time":      ("time",),
    "type":      ("type", "log_type", "logtype"),
    "src":       ("src", "srcip", "src_ip", "source.ip", "client_ip"),
    "dst":       ("dst", "dstip", "dst_ip", "destination.ip"),
    "method":    ("http_method", "method", "http.request.method"),
    "url":       ("http_url", "url", "uri", "url.original", "request", "resource"),
    "host":      ("http_host", "host", "url.domain"),
    "agent":     ("http_agent", "user_agent", "useragent", "user_agent.original", "web_client_type"),
    "retcode":   ("http_retcode", "status", "http.response.status_code", "retcode"),
    "action":    ("action", "event.action"),
    "main_type": ("main_type",),
    "sub_type":  ("sub_type", "subtype", "signature_subclass", "protection_name", "attack"),
    "severity":  ("severity_level", "severity", "pri"),
    "country":   ("srccountry", "src_country", "source.geo.country_name"),
    "product":   ("product", "productname", "blade"),
    "referer":   ("http_refer", "http_referer", "referer"),
    # поля мережевих з'єднань (Check Point / FortiGate) — для «мережевої мухи»
    "dport":     ("dst_port", "dstport", "svc", "service", "destination.port"),
    "sport":     ("src_port", "srcport", "sport_svc", "source.port"),
    "proto":     ("proto", "protocol", "transport_protocol", "network.transport"),
    "service_id": ("service_id", "app", "appi_name"),
    "inzone":    ("inzone", "srcintfrole"),
    "outzone":   ("outzone", "dstintfrole"),
}

# дії FortiWeb, які означають, що запит вже був визнаний шкідливим
ATTACK_ACTIONS = ("deny", "block", "erase", "redirect", "period_block", "captcha",
                  "drop", "reject", "prevent")  # останні три — Check Point


def _flatten(d: dict, prefix: str = "") -> dict:
    out = {}
    for k, v in d.items():
        key = f"{prefix}{k}".lower()
        if isinstance(v, dict):
            out.update(_flatten(v, key + "."))
        else:
            out[key] = v
    return out


def normalize(raw: dict) -> dict:
    """Зводить сирий словник полів до канонічної схеми."""
    low = {str(k).lower(): v for k, v in raw.items()}
    for k, v in list(low.items()):  # "fortiweb.http_url" -> також "http_url"
        if "." in k:
            low.setdefault(k.rsplit(".", 1)[1], v)
    rec = {}
    for canon, names in ALIASES.items():
        val = ""
        for n in names:
            if n in low and low[n] not in (None, "", "none", "N/A"):
                val = str(low[n])
                break
        rec[canon] = val
    rec["method"] = rec["method"].upper()
    # Check Point: повний URL у resource -> окремо хост і шлях
    u = rec["url"]
    if u.lower().startswith(("http://", "https://")):
        rest = u.split("://", 1)[1]
        host, _, path = rest.partition("/")
        rec["host"] = rec["host"] or host
        rec["url"] = "/" + path
    # голе ім'я хоста без шляху (Check Point firewall resource="host.local") — це не HTTP-запит
    if rec["url"] and "/" not in rec["url"]:
        rec["host"] = rec["host"] or rec["url"]
        rec["url"] = ""
    # Check Point: time:"1615377600" (epoch) замість date/time
    if not rec["date"] and rec["time"].isdigit() and len(rec["time"]) >= 9:
        from datetime import datetime
        t = datetime.fromtimestamp(int(rec["time"]))
        rec["date"], rec["time"] = f"{t:%Y-%m-%d}", f"{t:%H:%M:%S}"
    rec["label"] = guess_label(rec)
    if not rec["label"] and (low.get("attack") or low.get("protection_name")):
        rec["label"] = 1  # Check Point IPS / Threat Prevention
    # тип запису: web (є URL) / conn (мережеве з'єднання) / other
    if rec["url"]:
        rec["kind"] = "web"
    elif rec["src"] and (rec["dport"] or rec["proto"]):
        rec["kind"] = "conn"
    else:
        rec["kind"] = "other"
    return rec


def guess_label(rec: dict) -> int:
    """1 — FortiWeb вже вважає запит атакою (type=attack або дія deny/block).
    Використовується лише як «дофамін» для навчання і для оцінки якості.
    """
    if rec.get("type", "").lower() == "attack":
        return 1
    act = rec.get("action", "").lower()
    return int(any(a in act for a in ATTACK_ACTIONS))


_MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
_BSD_HDR = re.compile(r'^\s*(?:<\d+>)?([A-Za-z]{3})\s+(\d{1,2})\s+(\d\d:\d\d:\d\d)\s')
_ISO_HDR = re.compile(r'^\s*(?:<\d+>)?\d?\s*(\d{4}-\d\d-\d\d)T(\d\d:\d\d:\d\d)')


def _header_time(line: str):
    """Час із заголовка syslog (Check Point Spark не пише окремих date/time)."""
    m = _BSD_HDR.match(line)
    if m and m.group(1).lower() in _MONTHS:
        from datetime import date
        return f"{date.today().year}-{_MONTHS[m.group(1).lower()]:02d}-{int(m.group(2)):02d}", m.group(3)
    m = _ISO_HDR.match(line)
    if m:
        return m.group(1), m.group(2)
    return None


def parse_kv_line(line: str) -> dict | None:
    # syslog-префікс (<189>Oct  8 12:00:00 host ...) просто ігнорується
    pairs = _KV_RE.findall(line)
    cp = _CP_RE.findall(line)
    if len(cp) > len(pairs):  # формат Check Point key:"value";
        pairs = [(k, '"' + v + '"') for k, v in cp]
    if len(pairs) < 3:
        return None
    raw = {}
    for k, v in pairs:
        if len(v) >= 2 and v[0] == '"' and v[-1] == '"':
            v = v[1:-1].replace('\\"', '"')
        # перше входження перемагає: "src=x" всередині http_url не перезапише справжній src
        raw.setdefault(k, v)
    if "date" not in raw and "time" not in raw:
        ht = _header_time(line)
        if ht:
            raw["date"], raw["time"] = ht
    return raw


def iter_records(path: str) -> Iterator[dict]:
    """Автоматично визначає формат файлу і повертає нормалізовані записи."""
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        head = f.read(4096)
        f.seek(0)
        first = head.lstrip()[:1]
        if first in ("{", "["):
            yield from _iter_json(f)
        elif path.lower().endswith(".csv"):
            for row in csv.DictReader(f):
                yield normalize(row)
        else:
            yield from iter_lines(f)


def iter_lines(lines: Iterable[str]) -> Iterator[dict]:
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith("{"):
            try:
                yield normalize(_flatten(json.loads(line)))
            except json.JSONDecodeError:
                continue
            continue
        raw = parse_kv_line(line)
        if raw:
            yield normalize(raw)


def _iter_json(f) -> Iterator[dict]:
    text = f.read()
    try:
        data = json.loads(text)
        items = data if isinstance(data, list) else data.get("hits", {}).get("hits", [data])
        for it in items:
            if isinstance(it, dict) and "_source" in it:
                it = it["_source"]
            yield normalize(_flatten(it))
    except json.JSONDecodeError:  # JSON Lines
        yield from iter_lines(text.splitlines())
