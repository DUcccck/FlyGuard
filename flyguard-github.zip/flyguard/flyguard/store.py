"""Просте сховище конфігурації FlyGuard у config.json (потокобезпечне).

Тримає налаштування SOAR, BAS, honeypot та інтеграцій в одному файлі.
Секрети (API-ключі) зберігаються тут, тому файл має права 600.
"""
from __future__ import annotations

import json
import os
import threading

_LOCK = threading.RLock()

DEFAULT = {
    "integrations": {
        # kind: fortigate | fortiweb | checkpoint
        # приклад: {"name":"FGT","kind":"fortigate","host":"10.10.100.1","token":"...","group":"flyguard-block","verify_tls":False,"enabled":True}
    },
    "soar": {
        "enabled": False,
        "auto_block": False,          # автоблок без людини — лише з TTL і в межах guardrails
        "max_block_per_hour": 10,
        "default_ttl_min": 240,
        "notify": {"telegram_token": "", "telegram_chat": ""},
        "playbooks": [],              # [{name,enabled,min_risk,min_hits,source,action,integration,ttl_min,auto}]
    },
    "bas": {
        "allow_nets": ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"],
        "target": "",                 # напр. https://10.10.33.20  (лише внутрішній!)
        "last_run": None,
    },
    "honey": {
        "enabled": False,
        "ports": [2323, 2222, 3390, 8081, 4444],   # фальшиві порти-пастки (високі, без root)
        "feed_soar": True,
    },
}


def _merge(base: dict, extra: dict) -> dict:
    out = dict(base)
    for k, v in (extra or {}).items():
        out[k] = _merge(base[k], v) if isinstance(v, dict) and isinstance(base.get(k), dict) else v
    return out


class Store:
    def __init__(self, path: str = "config.json"):
        self.path = path
        self.data = _merge(DEFAULT, self._read())

    def _read(self) -> dict:
        if not os.path.exists(self.path):
            return {}
        try:
            with open(self.path, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            return {}

    def save(self):
        with _LOCK:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass

    def get(self, section: str) -> dict:
        with _LOCK:
            return json.loads(json.dumps(self.data.get(section, {})))  # глибока копія

    def update(self, section: str, patch: dict):
        with _LOCK:
            self.data[section] = _merge(self.data.get(section, {}), patch)
            self.save()

    def set_section(self, section: str, value):
        with _LOCK:
            self.data[section] = value
            self.save()

    def public(self) -> dict:
        """Конфіг для веб-інтерфейсу — із замаскованими секретами."""
        with _LOCK:
            d = json.loads(json.dumps(self.data))
        for it in d.get("integrations", {}).values():
            if it.get("token"):
                it["token"] = "••••" + str(it["token"])[-4:]
            if it.get("password"):
                it["password"] = "••••"
        tg = d.get("soar", {}).get("notify", {})
        if tg.get("telegram_token"):
            tg["telegram_token"] = "••••" + str(tg["telegram_token"])[-4:]
        return d
