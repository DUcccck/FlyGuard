"""FlyHoney — пастки (honeypots): фальшиві сервіси, до яких легітимний користувач не ходить.

Будь-яке з'єднання з портом-пасткою — майже напевно розвідка чи атака, бо нормального
трафіку тут не буває. Такий сигнал має дуже мало хибних спрацювань.

Безпечно: пастки лише слухають, трохи відповідають банером і логують джерело. Нічого не
виконують. За замовчуванням — високі порти (без root). Щоб виставити 23/3389 назовні,
прокиньте їх через VIP на FortiGate/Spark на порт-пастку.

Спіймані IP подаються у FlySOAR (якщо feed_soar) і показуються у веб-інтерфейсі.
"""
from __future__ import annotations

import socket
import threading
import time
from collections import deque

BANNERS = {
    23: b"\xff\xfd\x18\xff\xfd\x1f login: ",
    2323: b"login: ",
    2222: b"SSH-2.0-OpenSSH_8.9\r\n",
    21: b"220 FTP server ready\r\n",
    3390: b"",
    3389: b"",
    445: b"",
    8081: b"HTTP/1.1 401 Unauthorized\r\nWWW-Authenticate: Basic realm=\"admin\"\r\n\r\n",
    4444: b"",
}


class HoneyNet:
    def __init__(self, store, on_hit=None, log_path: str = "honey_hits.jsonl"):
        self.store = store
        self.on_hit = on_hit            # callback(hit_dict) -> у SOAR/alerts
        self.hits: deque = deque(maxlen=500)
        self.by_ip: dict[str, int] = {}
        self.servers: list = []
        self.log_path = log_path
        self.lock = threading.RLock()
        self._running = False

    def start(self):
        cfg = self.store.get("honey")
        if not cfg.get("enabled") or self._running:
            return
        self._running = True
        for port in cfg.get("ports", []):
            try:
                srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                srv.bind(("0.0.0.0", int(port)))
                srv.listen(16)
                self.servers.append(srv)
                threading.Thread(target=self._serve, args=(srv, int(port)), daemon=True).start()
            except OSError as e:
                print(f"[HONEY] порт {port} не відкрито: {e}", flush=True)
        if self.servers:
            print(f"[HONEY] пастки на портах: {', '.join(str(s.getsockname()[1]) for s in self.servers)}",
                  flush=True)

    def stop(self):
        self._running = False
        for s in self.servers:
            try:
                s.close()
            except OSError:
                pass
        self.servers = []

    def restart(self):
        self.stop()
        time.sleep(0.3)
        self.start()

    def _serve(self, srv: socket.socket, port: int):
        while self._running:
            try:
                conn, addr = srv.accept()
            except OSError:
                return
            threading.Thread(target=self._handle, args=(conn, addr, port), daemon=True).start()

    def _handle(self, conn: socket.socket, addr, port: int):
        ip = addr[0]
        data = b""
        try:
            conn.settimeout(3)
            banner = BANNERS.get(port, b"")
            if banner:
                conn.sendall(banner)
            data = conn.recv(256)
        except OSError:
            pass
        finally:
            try:
                conn.close()
            except OSError:
                pass
        self._record(ip, port, data)

    def _record(self, ip: str, port: int, data: bytes):
        with self.lock:
            self.by_ip[ip] = self.by_ip.get(ip, 0) + 1
            hit = {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "ip": ip, "port": port,
                   "count": self.by_ip[ip],
                   "data": data[:80].decode("latin-1", "replace").strip() if data else ""}
            self.hits.appendleft(hit)
        print(f"[HONEY] дотик до пастки: {ip} -> порт {port}", flush=True)
        try:
            import json
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(hit, ensure_ascii=False) + "\n")
        except OSError:
            pass
        if self.on_hit and self.store.get("honey").get("feed_soar", True):
            try:
                # пастка = максимальна підозра
                self.on_hit({"ip": ip, "risk": 1.0, "hits": self.by_ip[ip],
                             "why": [f"honeypot:port{port}"], "url": f"honeypot:{port}"})
            except Exception:
                pass

    def snapshot(self) -> dict:
        with self.lock:
            cfg = self.store.get("honey")
            top = sorted(self.by_ip.items(), key=lambda kv: -kv[1])[:10]
            return {"enabled": cfg.get("enabled", False),
                    "ports": cfg.get("ports", []),
                    "listening": [s.getsockname()[1] for s in self.servers],
                    "total_hits": sum(self.by_ip.values()),
                    "unique_ips": len(self.by_ip),
                    "top_ips": [{"ip": ip, "count": n} for ip, n in top],
                    "recent": list(self.hits)[:50]}
